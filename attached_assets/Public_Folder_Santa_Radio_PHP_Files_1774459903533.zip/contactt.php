

<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>




<!DOCTYPE html>
<html lang="en"><head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">


        <title><?php echo Config::get('seo.s7'); ?></title>


<!-- jQuery -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
  



</head>



<body id="page-top" onLoad="myFunction2();" >


               


    
		

    
    

    <section  id="contact" class="contact bg-primary">
        <div class="container">
        
             <h2>Contact Santa Radio</h2>
             <p>For Press or Corporate, feedback and suggestions, get in touch.</p>

        <div class="row">
        
         <div class="col-md-12">
        
         <div style="max-width:700px;margin-left: auto;
    margin-right: auto;">
            <form role="form" id="contactForm" class="contact-form center-block" data-toggle="validator" class="shake" >
            
               <div id="msgSubmit" class="h1 text-center hidden"></div> 
              <div class="clearfix"></div>   

              <div class="form-group">
                <div class="controls">
                  <input type="text" id="name" class="form-control" placeholder="Your Name" required data-error="Please enter your name">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="email" class="email form-control" id="email" placeholder="Your Email" required data-error="Please enter your email">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="text" id="msg_subject" class="form-control" placeholder="Subject" required data-error="Please enter your message subject">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <textarea id="message" rows="3" placeholder="Your Message to Santa" class="form-control" required data-error="Write your message"></textarea>
                  <div class="help-block with-errors"></div>
                </div>  
              </div>
													 
			
              <button type="submit" id="submit" class="xmasbutton"> Send Message </button>
              
              
              
           
            </form>   
            
            </div>  
        
        
         

        
        
        </div>
        
        
        
        </div>
    </section>
    
    


									

								 
    
<script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
<script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    


</body>
</html>
