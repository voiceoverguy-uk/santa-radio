



<?php

  $strSQL = mysqli_connect('localhost', 'cl57-messages', 'earwax69', 'cl57-messages');
  
  
  
  $strSQL = "SELECT * FROM messages2 WHERE live='Yes' ORDER BY id DESC LIMIT 3";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");

  
	
?>



   
<?
while($objResult = mysql_fetch_array($objQuery))
{
?>



<div class="incoming ">
			<table>
				<tr><td class="cell"></td><td class="cell"><b><?=$objResult["name"]?> asks</b><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="call textcell"><?=$objResult["message"]?></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="cell"><span class="datetext"><?=$objResult["date"]?></span></td><td class="cell"></td></tr>
			</table>
		</div>
        
        
		<div class="outgoing">
			<table>
			
				<tr><td class="cell"></td><td class="cell"><b>Santa says</b></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="call textcell"><?=$objResult["reply"]?></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="cell"></td><td class="cell"></td></tr>
			</table>
            
            
        
		</div>
        
     

  

  
  
   
     
  
<?
}
?>
