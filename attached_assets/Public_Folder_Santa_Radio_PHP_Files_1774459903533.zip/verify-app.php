<?php


 $name1 = $_GET['u'];

			
			$objConnect = mysql_connect("localhost","cl57-verify","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl57-verify");


		$result = mysql_query("SELECT id FROM messages2 WHERE email = '$name1' AND verified = 'YES'");
if(mysql_num_rows($result) == 0) {
     echo "No";
	
	
} else {
	
	 echo "Yes";
	
   
	
	
}
			

?>
         

                            
      
  
