
  <?php

// Read the now-playing file
$thesong = file_get_contents('radiodocs/Nowplaying.txt');
$str2 = trim($thesong);

// Split into artist and song
$parts = explode(" - ", $str2);

$one = $parts[0] ?? '';
$two = $parts[1] ?? '';

echo $one . "<br>";
echo $two . "<br><br>";

// --- Database Connection (MySQLi) ---
$mysqli = new mysqli("localhost", "cl57-thesongs", "earwax69", "cl57-thesongs");

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Prepare and execute query safely
$stmt = $mysqli->prepare("SELECT lyrics FROM messages2 WHERE artist = ? AND song = ?");
$stmt->bind_param("ss", $one, $two);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {

    echo "Sorry, no lyrics found";

} else {

    while ($row = $result->fetch_assoc()) {
        $duncan = nl2br($row["lyrics"]);
        echo "<p>{$duncan}</p>";
    }
}

$stmt->close();
$mysqli->close();

?>
