<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

$page = $_SERVER['PHP_SELF'];
$sec  = 30;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta http-equiv="refresh" content="<?php echo $sec; ?>;URL='<?php echo $page; ?>'">

<style>
body {
    font-family: 'Courgette', cursive;
    font-size: 19px;
    background:none;
    text-align:center;
}
</style>

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-sm-12">

<?php

// Read "Now Playing" info
$thesong = @file_get_contents("radiodocs/Nowplaying.txt");
$str2 = trim($thesong);

// Safely split into artist and song
$parts = explode(" - ", $str2, 2);
$one = $parts[0] ?? '';
$two = $parts[1] ?? '';

echo $one . "<br>";
echo $two . "<br><br>";

// ---- MySQLi Connection ----
$mysqli = new mysqli("localhost", "cl57-thesongs", "earwax69", "cl57-thesongs");

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Prepared statement
$stmt = $mysqli->prepare("SELECT lyrics FROM messages2 WHERE artist = ? AND song = ?");
$stmt->bind_param("ss", $one, $two);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Sorry, no lyrics found";
} else {
    while ($row = $result->fetch_assoc()) {
        $duncan = nl2br($row["lyrics"]);
        echo "<p>$duncan</p>";
    }
}

$stmt->close();
$mysqli->close();

?>

        </div>
    </div>
</div>

</body>
</html>
