<?php require_once 'theadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">

 
    
      <title>Friends of Santa Radio</title>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "Friends of Santa Radio",
  "description": "A festive collection of Santa Radio’s friends and partner websites, including British Voiceover Artist Guy Harris and Stag Communications.",
  "url": "https://www.santaradio.co.uk/links",
  "isPartOf": {
    "@type": "WebSite",
    "name": "Santa Radio",
    "url": "https://www.santaradio.co.uk"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Santa Radio",
    "url": "https://www.santaradio.co.uk/",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.santaradio.co.uk/assets/img/santa-radio-logo.jpg"
    }
  },
  "mainEntity": {
    "@type": "ItemList",
    "name": "Santa Radio Friends and Partners",
    "itemListElement": [
      {
        "@type": "Organization",
        "name": "VoiceoverGuy – Guy Harris",
        "url": "https://www.voiceoverguy.co.uk",
        "image": "https://www.santaradio.co.uk/assets/img/voiceoverguy-guy-harris-male-voiceover-banner.jpg",
        "description": "British Male Voiceover Artist Guy Harris, the voice of Santa Radio and many well-known brands."
      },
      {
        "@type": "Organization",
        "name": "Stag Communications",
        "url": "https://www.stagcommunications.co.uk/",
        "image": "https://santaradio.co.uk/assets/img/stag-communications.jpg",
        "description": "Creative radio production and imaging by Stag Communications, a proud partner of Santa Radio."
      }
    ]
  }
}
</script>

    <meta name="description" content="<?php echo Config::get('seo2.s2'); ?>">
    
    <meta name="twitter:card" content="app">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:description" content="<?php echo Config::get('seo2.s2'); ?>">
<meta name="twitter:app:id:iphone" content="1021183593">
<meta name="twitter:app:id:ipad" content="1021183593">
<meta name="twitter:app:id:googleplay" content="com.slinkyapps.santaradio">
<meta name="twitter:app:country" content="GB">
    
    
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
<link rel="manifest" href="assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


    
    
    




    

    <!-- Bootstrap Core CSS -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="../assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="../assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="../assets/css/animate.css" media="screen">
    
    <script src="../assets/js/ion.sound.js"></script>

 <link href="../xmas.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    
    
    
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}

function toggleDiv2(divId) {
	
	setTimeout(
    function() {
      $("#"+divId).slideToggle();
    }, 2000);
	
	
}
</script>

  <style>
  .equal, .equal > div[class*='col-'] {  
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    flex:1 0 auto;
}
</style>




</head>

<body id="page-top">

   <nav id="mainNav" class="navbar navbar-default navbar-fixed-top" style="background-color: white">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile displa y -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="../assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                   <?php include 'newmenu.php';?>  
                    
             
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
   
    
    
    
    
    

    <header>
 <div class="container">
        
        
         <div class="row"  >
         <div class="col-sm-12">
         
         <div  style=" padding-top:60px">
         
         
      <br>

<br>
                <img  src="assets/img/santa-radio-logo.png" alt="Friends of Santa Radio" title="Friends of Santa Radio"   class="img-responsive center-block" width="304">
                
         <br>    <br>    
     <p style="color:#FCFCFC; text-align:center;">
Santa loves sharing the festive spirit with friends from across radio, voiceover, and entertainment.<br>
Here are a few of the people and projects that help make Christmas brighter all year round.
</p>
			 
			 

   





  
        
        
        <div class="container">
        
        <div class="row" style="text-align:center">
 
  
      
    
       
       
       
   
<div class="col-md-12">
<a  href="https://xmasradio.mobi" target="_blank" title="Enjoy Christmas Everywhere"><img class="img-responsive center-block"  src="assets/img/xmas-radio.png" alt="Enjoy Christmas Everywhere" title="Enjoy Christmas Everywhere"></a>
</div>

<div class="col-md-12">
    <a href="https://www.voiceoverguy.co.uk" target="_blank" title="British Male Voiceover – Guy Harris">
      <img class="img-responsive center-block"
           src="https://www.santaradio.co.uk/assets/img/voiceoverguy-guy-harris-male-voiceover-banner.jpg"
           alt="British Male Voiceover – Guy Harris"
           title="British Male Voiceover – Guy Harris"
           style="max-width: 80%; height: auto; margin-top: 20px; margin-bottom: 10px;">
    </a>
    <p style="color:#FCFCFC; text-align:center; margin-top:10px;">🎙️ Brought to life by the voice of Santa himself — Guy Harris, British Male Voiceover Artist.</p>
  </div>

  <div class="col-md-12">
    <a href="https://www.stagcommunications.co.uk/" target="_blank" title="Stag Communications">
      <img class="img-responsive center-block"
           src="https://santaradio.co.uk/assets/img/stag-communications.jpg"
           alt="Stag Communications"
           title="Stag Communications">
    </a>
    <p style="color:#FCFCFC; text-align:center; margin-top:10px;">🎬 Creative production and radio imaging by our friends at Stag Communications.</p>
  </div>

  <div class="col-md-12">
    <a href="https://www.internet-radio.com" title="Internet Radio" target="_blank">
      <img class="img-responsive center-block"
           src="https://www.internet-radio.com/images/banners/Internet-Radio.com_Banner_Ad_Animated_Gif_728x90_v2.gif"
           alt="Internet Radio"
           title="Internet Radio"
           style="max-width: 80%; height: auto; margin-top: 20px; margin-bottom: 10px;">
    </a>
  </div>

			

<br><br><br><br>

    <!--

 <div class="col-md-6">
 <a  href="https://uk.radio.net/s/santa" target="_blank" title="Personalised Santa Letters">
 <img class="img-responsive center-block"  src="assets/img/radio-net-banner.jpeg" 
 alt="Personalised Santa Letters" 
 title="Personalised Santa Letters"></a>
</div>






 <div class="col-md-6">
 <a  href="https://www.official-santa-letters.co.uk" target="_blank" title="Personalised Santa Letters">
 <img class="img-responsive center-block"  src="assets/img/santa-letter.png" 
 alt="Personalised Santa Letters" 
 title="Personalised Santa Letters"></a>
</div>



 <div class="col-md-6">
	 
	 <a href="https://www.radioguide.fm/" title="Radioguide.fm"><img src="https://www.radioguide.fm/public/img/banners/animated.gif" alt="Radioguide.fm"></a>
	 

</div>

 <div class="col-md-6">
 <a  href="https://www.ukonlineradio.com" target="_blank" title="UK Online Radio">
 <img class="img-responsive center-block"  src="assets/img/uk-online-radio.png" 
 alt="UK Online Radio" 
 title="UK Online Radio"></a>
</div>

-->
			
			
		
			
			<iframe src="https://tunein.com/embed/player/s252505/" style="width:100%; height:100px; margin-top: 10px;" scrolling="no" frameborder="no"></iframe>

			
			<br>
			<br>

			







  

 


     <br>  <br>  <br>  <br>  <br>  <br>  <br>
 
     </div> 
                        
         
       

 
       
    </header>

  <?php include 'assets/php/footer.php';?>



  
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/new-age.js"></script>
    <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script-messages.js"></script>
    
    
    
    
    



    
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
      <script type="text/javascript" src="assets/js/custom.js"></script>

    
    
    


     <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>
</body>

</html>
