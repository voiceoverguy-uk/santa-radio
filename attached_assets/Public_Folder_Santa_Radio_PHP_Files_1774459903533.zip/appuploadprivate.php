<?php

///This is the file used by Santa Voicemail and Santa Messages to upload audio


$msg = " ".var_dump($_FILES)." ";
$new_image_name = $_FILES["userfile"]["name"];
move_uploaded_file($_FILES["userfile"]["tmp_name"], getcwd() . "/audio/" . $new_image_name);




$to = "audio@appstyle.co.uk";
$subject = "Private Santa Voicemail Message";
$from = "santaaudio@voiceoverguy.co.uk";
$headers = "From: $from\r\n";


//$headers .= 'Cc: markhitchings@googlemail.com' . "\r\n";
//$headers .= 'Cc: wearesantaradio@gmail.com' . "\r\n";






$headers .= "MIME-Version: 1.0\r\n"
  ."Content-Type: multipart/mixed; boundary=\"1a2a3a\"";
 
$message .= "This audio has just been uploaded from the iOS app \r\n"
  ."--1a2a3a\r\n";
 
$message .= "Content-Type: text/html; charset=\"iso-8859-1\"\r\n"
  ."Content-Transfer-Encoding: 7bit\r\n\r\n"
  ."Santa Voicemail"
  ."<p>http://www.santaradio.co.uk/audio/$new_image_name</p> \r\n"
  ."--1a2a3a\r\n";
 
 
 //http://www.santaradio.co.uk/audio/SantaVoicemail20161023013414.mp3
 
 //https://www.voiceoverguy.co.uk/radiodocs/uploads/2016-10-16-----08:44:55.mp3
$file = file_get_contents("https://www.santaradio.co.uk/audio/$new_image_name");
 
$message .= "Content-Type: audio/mpeg; name=\"$new_image_name\"\r\n"
  ."Content-Transfer-Encoding: base64\r\n"
  ."Content-disposition: attachment; file=\"c\"\r\n"
  ."\r\n"
  .chunk_split(base64_encode($file))
  ."--1a2a3a--";
 
// Send email
 
$success = mail($to,$subject,$message,$headers);








?>




