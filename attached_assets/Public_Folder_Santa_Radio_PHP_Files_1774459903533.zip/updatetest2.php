<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
 
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
   
   
   
    
 <script type="text/javascript" src="jquery.js"></script>




 <script>
$(document).ready(function() {
	


  $.ajaxSetup({ cache: false }); 
  setInterval(function() {
 console.log('test called');

//myFunction()
	
  }, 1000); // the "3000" 
});
</script>




<script type='text/javascript'>
function myFunction(){
 $.ajax({
    type: "get",
    url: "bringsong3.php",
    success: function(content){
      $("#contentdiv").html(content);
    }
  });
}
</script>

</head>

<body>


 <a href="#" onclick="myFunction()">LinkText</a>


<div id="contentdiv"></div>
<?php
$url = file_get_contents("http://149.255.59.164:8041/index.html");
$xml = simplexml_load_string($url);
foreach ($xml->SONGTITLE as $cancion)
$cancion = utf8_decode($cancion);

$select = explode(" - ",$cancion);
$artista = chop($select[0]);
$titulo  = chop($select[1]);

echo "<p> dd<font color=Black font face='Arial' size='4pt'>$artista</br>";
echo "<p> <font color=Black font face='Arial' size='2.5pt'>$titulo</p>";?>



    
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
   


</body>
</html>