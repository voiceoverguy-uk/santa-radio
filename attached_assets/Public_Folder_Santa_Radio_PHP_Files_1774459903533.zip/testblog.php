
<?php
$mysql_host     = 'voiceoverguy.co.uk';   # use your mysql host host (ussually 127.0.0.1)
$mysql_user     = 'cl10-nreblog';            # use your mysql user
$mysql_pass     = 'earwax69';            # use your mysql password here
$mysql_database = 'cl10-nreblog'; # use your mysql databas here

if(!$link = mysqli_connect($mysql_host, $mysql_user, $mysql_pass)){
    echo 'could not connect database';
    }
    
if(!mysqli_select_db($link, $mysql_database)){
   echo "Database not found";
   die();       
   }


$query = mysqli_query($link, "SELECT * 
                              FROM messages2 
                              WHERE url = '{$_GET['url']}' ");



//$query = mysqli_query($link, "SELECT * 
     //                         FROM messages2 
							  
		//					  WHERE url = minecraft-combat-voiceover");
          //                   // WHERE url = '{$_GET['url']}' ");



    //$row = mysqli_fetch_assoc($query);

 $row = mysqli_fetch_assoc($query);
   
       
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  
    



</head>


<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
<nav class="topnav">

</nav>
</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

</a> 
<br>

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >
<h2>



  




</h2>

<h1><?php echo $row['page_title']; ?> </h1>
<?php echo $row['info']; ?>
<div class="bar"></div>
</div>
</div>
</div>
</div>



<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-6" >
<?php echo $row['text1']; ?>
</div>

<div class="col-md-6" >
<br>


  

<?php
$string2 = $row['whatvideo'];

if ( $string2 == "1" ){ ?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo $row['video']; ?>" frameborder="0" allowfullscreen></iframe>


<? }elseif ( $string2 == "0" ){ ?>

<iframe src="//player.vimeo.com/video/<?php echo $row['video']; ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } else { ?>

<?php echo $row['video']; ?>


<?php } ?>




</div>
</div>



<div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive  imageborder"   src="https://www.voiceoverguy.co.uk/assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</div>

<div class="col-md-6" >
<?php echo $row['text2']; ?>
</div>
</div>



<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo $row['bottomtext']; ?>

<div class="bar"></div>

<div style="text-align:center">
<p>



 <a  href="https://twitter.com/intent/tweet?text=<?php echo $row['page_title']; ?>%0A https://www.voiceoverguy.co.uk/<?php echo $row['url']; ?> %0A %23Voiceover %23VoiceoverGuy <?php echo $row['twitter']; ?>" title="<?php echo $row['page_title']; ?>"  >
<i class="fa fa-twitter fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i>
</a>



<a href="#" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(location.href),'facebook-share-dialog','width=626,height=436');return false;"><i class="fa fa-facebook fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>
 


<a href="https://plus.google.com/share?url=https://www.voiceoverguy.co.uk/<?php echo $row['url']; ?>" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus fa-2x" title="" style="margin-right:6px;margin-left:10px"> </i></a>


<a  href="javascript:void(0)" onclick="window.open( 'http://www.linkedin.com/shareArticle?mini=true&url=https://www.voiceoverguy.co.uk/<?php echo $row['url']; ?>', 'sharer', 'toolbar=0, status=0, width=626, height=436');return false;" title="Linkedin"><i class="fa fa-linkedin fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>




</p>
</div>

<div class="bar"></div>

 




           
            <?
	 

$objConnect = mysql_connect("voiceoverguy.co.uk","cl10-nreblog","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl10-nreblog");


$order_by2 = "ORDER BY RAND()"; // Default order



$str2SQL = "SELECT * FROM messages2 ".$order_by2." LIMIT 3";
$objQuery2 = mysql_query($str2SQL) or die ("Error Query [".$str2SQL."]");

?>


   
<?
while($objResult2 = mysql_fetch_array($objQuery2))
{
?>


<div class="col-md-4" >


<h2  style="text-align:center"><?php echo $objResult2['page_title']; ?></h2>

<a href="<?php echo $objResult2['url']; ?>" title="<?php echo $objResult2['alt']; ?>">
<div class="effect1">
<img  alt="<?php echo $objResult2['alt']; ?>" title="<?php echo $objResult2['alt']; ?>" class="img-responsive"   src="https://www.voiceoverguy.co.uk/assets/img/blog/<?php echo $objResult2['image']; ?>" />
</div>
</a>




 

      </div>
      
      

  
  
   
     
  
<?
}
?>









</div>
</div>
</div>
</div>




</div>




</div>
</body>
</html>


