

<?php require_once 'theadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html>
<html lang="en"><head>
   

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">

 
    
<link href='https://fonts.googleapis.com/css?family=Courgette' rel='stylesheet'>
    


    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

  

	<style>
body {background:none}
		</style>
</head>

<body id="page-top">

 
    
    
    
    
    

    <header>
  <div class="col-md-12" style="color: white; text-align: center;">
                    <div class="container-fluid">
                        

						   <p style="text-align: center;font-size: 22px; font-family: 'Courgette';"><?php echo html_entity_decode(Config::get('seo.fs13')); ?></p>
		
                        <div class="row">
							
							
							
							 <div class="col-sm-3" >
                                <div class="feature-item">
									<a href="<?php echo Config::get('seo.fs1'); ?>"  style="text-decoration: none;" target="_blank">
                                  <img  src="assets/img/home-ad2.jpg" alt="Santa Video" title="Santa Video"  class="img-responsive center-block img-rounded" >
                                   
										  <p class="text-muted" style="font-size: 20px;font-family: 'Courgette';color: white;"><?php echo html_entity_decode(Config::get('seo.fs2')); ?><br>
											  
											  <span style="font-size: 13px;font-family: 'Courgette';color: white;"> <?php echo html_entity_decode(Config::get('seo.fs3')); ?></span></p> 
									
									
									
									</a>                                
                                </div>  </div>
                         
							
							
							
							
                            <div class="col-sm-3">
                                
							
							
                                <div class="feature-item">
									<a href="<?php echo Config::get('seo.fs4'); ?>" style="text-decoration: none;"  target="_blank">
										
									  <img  src="assets/img/home-ad5.jpg" alt="Santa Video" title="Santa Video"  class="img-responsive center-block img-rounded" >
                                   
						 <p class="text-muted" style="font-size: 20px;font-family: 'Libre Baskerville', serif;color: white;"><?php echo html_entity_decode(Config::get('seo.fs5')); ?><br>
											  
											  <span style="font-size: 13px;font-family: 'Libre Baskerville', serif;color: white;"><?php echo html_entity_decode(Config::get('seo.fs6')); ?></span></p>  
										</a>
                                </div>

								
								
								
								
								
								
								
                            </div>
							
							
                        
                            
							
							
                            <div class="col-sm-3">
                                <div class="feature-item">
									<a href="<?php echo Config::get('seo.fs7'); ?>" style="text-decoration: none;" target="_blank">
                                    <img  src="assets/img/home-ad4.jpg" alt="Santa Video" title="Santa Video"  class="img-responsive center-block img-rounded" >
                                   
								 <p class="text-muted" style="font-size: 20px;font-family: 'Courgette';color: white;"><?php echo html_entity_decode(Config::get('seo.fs8')); ?><br>
											  
											  <span style="font-size: 13px;font-family: 'Courgette';color: white;"><?php echo html_entity_decode(Config::get('seo.fs9')); ?></span></p>  </a>                                 
                                </div>
                            </div>
							
                            
                        
                            <div class="col-sm-3">
                                <div class="feature-item">
									<a href="<?php echo Config::get('seo.fs10'); ?>"  style="text-decoration: none;" target="_blank">
                                  <img  src="assets/img/home-ad3.jpg" alt="Santa Video" title="Santa Video"  class="img-responsive center-block img-rounded" >
                                   
								 <p class="text-muted" style="font-size: 20px;font-family: 'Courgette';color: white;"><?php echo html_entity_decode(Config::get('seo.fs11')); ?><br>
											  
											  <span style="font-size: 13px;font-family: 'Courgette';color: white;"><?php echo html_entity_decode(Config::get('seo.fs12')); ?></span></p>   </a>                                 
                                </div>
                            </div>
                           
							
							 
							 
					
						
						
				
					
					
					
					
					
					
					
					
					
					
					
					
					
			




						</div>
					
					
				
				</div>
					</div>
		
				
	
	

       
    </header>
    
   
  
  
 
 


  
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/new-age.js"></script>

    
    
    
    



    

  
  

  
 
 






	 
</body>

</html>
