<?php

print "<p class='success'>Yippee. you have successfully joined Santa's mailing list.</p>";








 $name1 = $_POST['userName'];
 $message1 = $_POST['userEmail'];
 $from1 = "Website";

  $date = date("Y-m-d H:i:s");





$to = $message1;
$subject = "Santa Radio - Please verifiy email address $name1";
$txt = "
<html>
<head>
<title>Hi  $name1</title>
</head>
<body>
<h3>Thanks for joining the Santa Radio mailing list. We’d love to occasionally keep you updated with updates here at Santa HQ.</h3>
<br>
<h3><a href='http://www.santaradio.co.uk/verify?u=$message1'>Click to to verify your email address</a></h3>
<br>

<h3>Do have a look around the website.</h3>
<h3><a href='http://www.santaradio.co.uk'>www.santaradio.co.uk</a></h3>
<table>
<tr>
<th><a href='https://twitter.com/WeAreSantaRadio'><img src='http://www.santaradio.co.uk/mailer1.png'  width='100px' height='186px'></a><a href='https://www.facebook.com/santaradiouk'><img src='http://www.santaradio.co.uk/mailer2.png' width='100px' height='186px'></a></th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>
</body>
</html>
";



$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

$headers .= 'From: <santa@santaradio.co.uk>' . "\r\n";
//$headers .= 'Cc: santaaudio@voiceoverguy.co.uk' . "\r\n";





mail($to,$subject,$txt,$headers);







$con = mysql_connect("localhost","cl57-mlist","earwax69");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("cl57-mlist", $con);
 
$sql="INSERT INTO messages2 (name, email, date, wherefrom)
VALUES
('$name1','$message1','$date','$from1')";
 
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 
mysql_close($con)




	
	



?>
