 
 
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

 



<style>
body {font-family: 'Courgette', cursive;
        font-size: 19px;background:none; text-align:center}
		
	

</style>
 
</head>
<body>
  
   <div class="container">
        
        
         <div class="row" >
         <div class="col-sm-12"  >
  
  
          <? 
	 
	 
	
	 
 $thesong = file_get_contents( "radiodocs/Nowplaying.txt" ); 
	//   $thesong = "Queen - Thank God It's Christmas"; 
	
$str2 = trim($thesong);


   $parts = explode(" - ", $str2);
   $one = $parts[0];
   $two = $parts[1];
	
	
	
	
	
	//
	echo $one;
	echo "<br>";
	echo $two;

	echo "<br>";
	
	
	
$two = addslashes($two);

echo "<br>";


	
$objConnect = mysql_connect("localhost","cl57-thesongs","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl57-thesongs");


//mysql_query("INSERT INTO table (categoryname) VALUES ('".$categoryname."')");
    
$strSQL = "SELECT * FROM messages2  WHERE artist = '$one' && song = '$two'";

                              


$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");

?>



   
<?



if (mysql_num_rows($objQuery) == 0) {
   echo "Sorry, no lyrics found"; 
} else { 
 



while($objResult = mysql_fetch_array($objQuery))
{
?>




 <? $duncan = nl2br($objResult["lyrics"]); ?>

    <p><?php echo $duncan ?></p>
  
    
   





 
  
<?
}

}


?>


</div></div></div>




</body>
</html>
    
    
   
       

 
   

  

    

