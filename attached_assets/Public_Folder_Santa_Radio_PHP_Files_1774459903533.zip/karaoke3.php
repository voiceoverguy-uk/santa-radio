<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

$page = $_SERVER['PHP_SELF'];
$sec  = 30;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="<?php echo $sec; ?>;URL='<?php echo $page ?>'">

<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

<link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
<link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">
<link href="assets/css/new-age.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">

<style>
body { text-align:center }
</style>

</head>

<body style="background:url(https://www.santaradio.co.uk/assets/img/TheMainBG.jpg) no-repeat center center fixed;
  background-size:cover; color:#FFFFFF">

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div style="padding-top:10px">
                <img src="https://www.santaradio.co.uk/assets/img/santa-radio-logo.png"
                     alt="Personalised Santa Messages"
                     class="img-responsive center-block"
                     width="504">

                <h1><a href="app1">Menu</a></h1>
                <br>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-sm-12">

<?php

// Read file safely
$thesong = @file_get_contents('radiodocs/Nowplaying.txt');
$str2 = trim($thesong);

// Split "Artist - Song"
$parts = explode(" - ", $str2, 2);

$one = $parts[0] ?? '';
$two = $parts[1] ?? '';

echo $one . "<br>";
echo $two . "<br><br>";

// --- MySQLi Connection ---
$mysqli = new mysqli("localhost", "cl57-thesongs", "earwax69", "cl57-thesongs");

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Prepared statement prevents SQL injection
$stmt = $mysqli->prepare("SELECT lyrics FROM messages2 WHERE artist = ? AND song = ?");
$stmt->bind_param("ss", $one, $two);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Sorry, no lyrics found";
} else {
    while ($row = $result->fetch_assoc()) {
        $lyricsFormatted = nl2br($row["lyrics"]);
        echo "<p>{$lyricsFormatted}</p>";
    }
}

$stmt->close();
$mysqli->close();

?>

        </div>
    </div>
</div>

</body>
</html>
