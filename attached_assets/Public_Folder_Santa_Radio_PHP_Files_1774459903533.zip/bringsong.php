<?php 
$theverabke = date("gisA");   
$bring = file_get_contents('radiodocs/Nowplaying.txt' ); 
$fullsong = $bring;

 $str2 = trim($bring);
    $parts = explode(" - ", $str2);
    $one = $parts[0];
    $two = $parts[1];
	$str =  $one;
    $str = strtolower($str);
   $id = $str;
    $id = str_replace(' ', '-', $id);

if (empty($id)){ $strippedartist = "santa-radio"; }
else{ $strippedartist = $id; }

if (empty($fullsong)){ $thefullsong = "Loading...";}
else{ $thefullsong = $fullsong; }



echo $thefullsong;


?>

