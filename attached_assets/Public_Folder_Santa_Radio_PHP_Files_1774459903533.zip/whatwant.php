<?php require_once 'theadmin/app/initforapp.php';?>


<?php echo html_entity_decode(Config::get('seo.d1')); ?>
