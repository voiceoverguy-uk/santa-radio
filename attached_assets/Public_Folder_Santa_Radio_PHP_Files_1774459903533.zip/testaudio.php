<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	
	<audio controls autoplay muted>
  <source src="https://streaming05.liveboxstream.uk/stream/mhitchin/stream.pls" type="audio/ogg">
  <source src="https://streaming05.liveboxstream.uk/stream/mhitchin/stream.pls" type="audio/mpeg">
Your browser does not support the audio element.
</audio>
</body>
</html>