
<?php require_once 'theadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html>
<html lang="en">

<head>



    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">


         
          <? 
	 

	
$objConnect = mysql_connect("localhost","cl57-thesongs","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl57-thesongs");

$strSQL = "SELECT * FROM messages2  WHERE id = '".$_GET["s"]."'";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");

?>



   
<?
while($objResult = mysql_fetch_array($objQuery))
{
?>




 
    
      <title><?=$objResult["artist"]?> - <?=$objResult["song"]?> - Santa Radio</title>

    <meta name="description" content="<?=$objResult["info"]?>">
    
    
    <meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@WeAreSantaRadio">
<meta name="twitter:title" content="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Santa Radio">
<meta name="twitter:description" content="<?=$objResult["info"]?>">
<meta name="twitter:image" content="../assets/img/artists/<?=$objResult["image"]?>">

    
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="192x192"  href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="manifest" href="assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/img/artists/<?=$objResult["image"]?>">
<meta name="theme-color" content="#ffffff">


    
    <script type="text/javascript">
function toggleDiv(divId) {
   $("#"+divId).slideToggle();
}
</script>
    
    
    
    
    <script type="application/ld+json">
{ "@context" : "http://schema.org",
  "@type" : "Organization",
  "name" : "<?=$objResult["artist"]?>",
  "url" : "https://www.santaradio.co.uk/artist?s=<?=$objResult["id"]?>",
  "logo": "https://santaradio.co.uk/assets/img/artists/<?=$objResult["image"]?>",
  
  "sameAs" : [ "https://www.facebook.com/santaradiouk",
    "https://twitter.com/WeAreSantaRadio",
    "https://www.youtube.com/channel/UCtvHjue7LusTEpMTpByuC8A"] 
}
</script>



<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "item": {
      "@id": "https://www.santaradio.co.uk/christmas-music/",
      "name": "Christmas Music",
      "image": "https://santaradio.co.uk/santa-radio.png"
    }
  },{
    "@type": "ListItem",
    "position": 2,
    "item": {
      "@id": "https://www.santaradio.co.uk/artist?s=<?=$objResult["id"]?>",
      "name": "<?=$objResult["artist"]?>",
      "image": "https://santaradio.co.uk/assets/img/artists/<?=$objResult["image"]?>"
    }
  }
  
  ]
}
</script>
	




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    

   
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}
</script>



    
   




</head>

<body id="page-top" style="background-color:#222222">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
                
                
                
                  <?php include 'assets/php/menu.php';?>
                
          
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>





 </section>
    
    
    
   

    
    
    
     <section class="cta4">
        <div class="cta-content">
            <div class="container">
            
               <div class="container">
        
        
         <div class="row"  >
         <div class="col-sm-12">
         
         <div  style=" padding-top:40px">
         
         
   
                  <img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio"  class="img-responsive center-block" width="564">
               
                
         <br>    <br>    
   
     

       
   
  
        
     </div></div></div>
         
        
         <div class="container">
        
        
         <div class="row" style="max-width:500px;  margin: auto;">
         <div class="col-sm-12" style="color:#DBDBDB; text-align:center; margin-top:-60px" >
       
         



<h2><?=$objResult["artist"]?></h2>
<h1><?=$objResult["song"]?></h1>








 <button style="background-color:#E8E8E8"  onClick="javascript:toggleDiv('myContent');" type="submit" id="submit" class="btn btn-xl page-scroll center-block">Lyrics</button>
  <br>

<div id="myContent" style="max-width:450px; background-color: #FFFFFF; border-radius: 25px;margin-left: auto;margin-right: auto; margin-bottom:20px;padding:20px;display:none;}">
   

   
   
   <?  
   

   if (!isset($objResult["lyrics"]) || $objResult["lyrics"] !== '') {
  


 
}

else{
	
	?>
   
   <br>
    <p style="color:#2D2D2D">The Elves are working on it, come back soon.</p>
   
	
	<?
}
?>





 
  <? $duncan = nl2br($objResult["lyrics"]); ?>
    <p style="color:#2D2D2D"><?php echo $duncan ?></p>
  
  



</div>










<img class="img-rounded img-responsive center-block" src="../assets/img/artists/<?=$objResult["image"]?>" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<br>

<?  
   
   $thelink = $objResult["info"];
   
   
   if (!isset($thelink) || $thelink !== '') {
  

  
  
  ?>
   <p><?=$objResult["info"]?></p>
  
  <?
}

?>






<br>






<br>






 <a  href="https://twitter.com/intent/tweet?text=My favourite %23Christmas song on Santa Radio - <?=$objResult["artist"]?> - <?=$objResult["song"]?> %0A @WeAreSantaRadio %0A %23christmasmusic"  ><i style="color:#F4F4F4" class="fa fa-twitter fa-2x" aria-hidden="true"></i></a>

     <br><br>
     
     
     
   <?  
   
   $thelink = $objResult["link"];
   
   
   if (!isset($thelink) || $thelink !== '') {
  

  
  
  ?>
    <a style=" background-color:#E8E8E8" target="_blank" class="btn btn-outline btn-xl center-block" href="<?=$objResult["link"]?>" title="More info on <?=$objResult["artist"]?> - <?=$objResult["song"]?>">More info about<br><strong><?=$objResult["artist"]?></strong></a>


  <?
}

?>








 <?  
   

   if (!isset($objResult["youtube"]) || $objResult["youtube"] !== '') {
  

?>



<br>
<h2>Music Video</h2>



 <?php
  $browser = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    if ($browser == true){
		
		
		?>
        
        <a  href="https://www.youtube.com/watch?v=<?=$objResult["youtube"]?>">
<img class="img-rounded img-responsive center-block" src="https://img.youtube.com/vi/<?=$objResult["youtube"]?>/hqdefault.jpg" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<img style="margin-top:-76%;" class="img-rounded img-responsive center-block" src="assets/img/video-border.png" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >
 </a>
        
        <?

  }
  else{  ?>
	  
	<a class="video"  title="<?=$objResult["artist"]?> - <?=$objResult["song"]?>" href="https://www.youtube.com/watch?v=<?=$objResult["youtube"]?>">
<img class="img-rounded img-responsive center-block" src="https://img.youtube.com/vi/<?=$objResult["youtube"]?>/hqdefault.jpg" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<img style="margin-top:-76%;" class="img-rounded img-responsive center-block" src="assets/img/video-border.png" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >
 </a>
<?	  
  }
?>




  


<?
 
}

else{
	

  
  
}
?>





 
 
 
 
 
 
 
 



 
  
<?
}
?>









            </div>
               
    
                                
               </div>
               
                        
       
    

                
               </div>
                
                 
            </div>
            
                
                
                  
              

 
        </div>
        
                
       
           
        </div>
        </div>
      
    </section>
    
    
    
    
   
       

 
   

   <?php include 'assets/php/footer.php';?>

    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/new-age.js"></script>
    <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    
    
    
    
    



    
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
      <script type="text/javascript" src="assets/js/custom.js"></script>

    

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
	<script type="text/javascript" src="fancybox-youtube/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" type="text/css" href="fancybox-youtube/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
    <script type="text/javascript" src="fancybox-youtube/fancybox/video.js"></script>
 	


     <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>



</body>

</html>
