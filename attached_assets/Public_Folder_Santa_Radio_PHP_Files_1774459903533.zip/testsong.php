<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
	
	
		<?php
$thesong = "<script src=\"https://embed.radio.co/embed/s64f76aae3/song.js\"></script>";
	
	
echo($thesong);
	
?>
	

	
	
	<?php

//require_once "bringsong.php";

//function getplaintextintrofromhtml($html) {

    // Remove the HTML tags
  //  $html = strip_tags($html);

    // Convert HTML entities to single characters
  //  $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');

  //  return $html;

//}

//$html = file_get_contents('bringsong.php');

//echo getplaintextintrofromhtml($html);
?>

	
	<?php // include("bringsong.php"); ?>
	
	
	<br><br><br><br>
	<script src="https://embed.radio.co/embed/s64f76aae3/song.js"></script>
	
</body>
</html>