<?php 
$theverabke = time();  
$bring = file_get_contents('radiodocs/Nowplaying.txt'); 
$fullsong = $bring;

 $str2 = trim($bring);
    $parts = explode(" - ", $str2);
    $one = $parts[0];
    $two = $parts[1];
	$str =  $one;
    $str = strtolower($str);
    $id = $str;
    $id = str_replace(' ', '-', $id);

     if (empty($id)){ $strippedartist = "santa-radio"; }

else{ $strippedartist = $id; }





if (empty($fullsong)){ $thefullsong = "Santa Radio";}
else{ $thefullsong = $fullsong; }





?>


<script type="text/javascript">
jQuery(function(){

   // Fade In
   $("#myImage").fadeIn();



});
</script>



	<style>
	.radioco_artwork img{
	height:210px;
	width: 210px;
		margin-top:-210px;
		 border-radius: 50%;
	}
		
		
	</style>
<script class="center-block img-circle" src="https://embed.radio.co/embed/s64f76aae3/artwork.js"></script>




<!--



<img style="margin-top:-258px" src="assets/img/santa-radio-globe.gif" width="328px" class="center-block" >   
<img style="margin-top:-328px" src="assets/img/santa-radio-globe.png" width="328px" class="center-block" 

title="Now playing <? echo $thefullsong;?> on Santa Radio" 
alt="Now playing <? echo $thefullsong;?> on Santa Radio"

>

-->
	
	