[playlist]
PlaylistName=Playlist 001
File1=http://81.136.155.183:8000/45Radio32k
Title1=45Radio
Length1=-1
NumberOfEntries=1
Version=2
