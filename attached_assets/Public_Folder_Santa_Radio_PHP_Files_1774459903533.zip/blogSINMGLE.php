
<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>


<?php
$mysql_host     = 'localhost';   # use your mysql host host (ussually 127.0.0.1)
$mysql_user     = 'cl57-santablog';            # use your mysql user
$mysql_pass     = 'earwax69';            # use your mysql password here
$mysql_database = 'cl57-santablog'; # use your mysql databas here

if(!$link = mysqli_connect($mysql_host, $mysql_user, $mysql_pass)){
    echo 'could not connect database';
    }
    
if(!mysqli_select_db($link, $mysql_database)){
   echo "Database not found";
   die();       
   }


$query = mysqli_query($link, "SELECT * 
                              FROM messages2 
                              WHERE url = '{$_GET['u']}' ");



//$query = mysqli_query($link, "SELECT * 
     //                         FROM messages2 
							  
		//					  WHERE url = minecraft-combat-voiceover");
          //                   // WHERE url = '{$_GET['url']}' ");



    //$row = mysqli_fetch_assoc($query);

 $row = mysqli_fetch_assoc($query);
   
       
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="<?php echo $row['video']; ?>">


        <title><?php echo $row['meta_title']; ?></title>

    <meta name="description" content="<?php echo $row['page_desc']; ?>">
     <meta name="twitter:card" content="app">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:description" content="<?php echo $row['page_desc']; ?>">
<meta name="twitter:app:id:iphone" content="1021183593">
<meta name="twitter:app:id:ipad" content="1021183593">
<meta name="twitter:app:id:googleplay" content="com.slinkyapps.santaradio">
<meta name="twitter:app:country" content="GB">
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


   

    
    




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
   
   <style>
   
   
   
	
	@media only screen and (max-width: 1026px) {
    .hide22{
	display:none;
}
	
	
	}
	
	
	</style>
    


</head>



<body id="page-top" >

 <!-- onload="timer = setTimeout('reload()',1);" --> 

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                    <?php include 'assets/php/menu.php';?>  
                    
             
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
   
   
   
   
   
   
    <section class="cta4">
        <div class="cta-content">
            <div class="container" style="text-align:center; color:#FFFFFF;">
             <img  src="assets/img/santa-radio-logo.png" alt="Santa Messages - <?php echo Config::get('seo29.m1'); ?>" title="Santa Messages - <?php echo Config::get('seo29.m2'); ?>"   class="img-responsive center-block " width="384">
             


<h1><?php echo $row['page_title']; ?> </h1>
				<p class="text-muted"><?php echo $row['info']; ?></p>


                 
             
             <p>
             
 </p>
             
       
          </div>
        </div>
      
    </section>
    
    
    

    
        
    
    
    
        
   
    
    
    
    
    
    
    
    
    
    
    

    
   

         
<div class="container">



<div class="row">
<div class="col-md-6" >
<?php echo $row['text1']; ?>
</div>

<div class="col-md-6" >
<br>


  

<?php
$string2 = $row['whatvideo'];

if ( $string2 == "1" ){ ?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo $row['video']; ?>" frameborder="0" allowfullscreen></iframe>


<? }elseif ( $string2 == "0" ){ ?>

<iframe src="//player.vimeo.com/video/<?php echo $row['video']; ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<? }elseif ( $string2 == "2" ){ ?>

<img  alt="<?php echo $row['alt2']; ?>" title="<?php echo $row['alt2']; ?>" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/<?php echo $row['video']; ?>" />
<?php } else { ?>

<?php echo $row['video']; ?>


<?php } ?>




</div>
</div>








<div class="row">


<div class="col-md-6" >
<br>
<div class="effect1">
   <?php
	
	if (
    $row['image'] == '' ||
    $row['image'] == null ||
    empty($row['image']) ||
    !$row['image']
) {
   
}
else { ?>
  <img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/<?php echo $row['image']; ?>" />
  
<? } ?>


</div>
	</div>

<div class="col-md-6" >
<?php echo $row['text2']; ?>
</div>


</div>


 <br>
<div class="row">


<div class="col-md-6" >
<br>
<div class="effect1">
<?php echo $row['text3']; ?>
</div>
</div>

<div class="col-md-6" >
  <?php
	
	if (
    $row['image2'] == '' ||
    $row['image2'] == null ||
    empty($row['image2']) ||
    !$row['image2']
) {
   
}
else { ?>

  <img  alt="<?php echo $row['alt3']; ?>" title="<?php echo $row['alt3']; ?>" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/<?php echo $row['image2']; ?>" />
  
<? } ?>




</div>

	</div>
	
	
	 <br>
<div class="row">

<div class="col-md-6" >
<br>
<div class="effect1">
  <?php
	
	if (
    $row['image3'] == '' ||
    $row['image3'] == null ||
    empty($row['image3']) ||
    !$row['image3']
) {
   
}
else { ?>
  <img  alt="<?php echo $row['alt4']; ?>" title="<?php echo $row['alt4']; ?>" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/<?php echo $row['image3']; ?>" />
  
<? } ?>

</div>
</div>

<div class="col-md-6" >
<?php echo $row['text4']; ?>
</div>







</div>

 <br>


<div class="row">
<div class="col-md-12" >


<?php echo $row['bottomtext']; ?>

<hr>
 
 <br>
 


<div style="text-align:center">
<p>



 <a  href="https://twitter.com/intent/tweet?text=<?php echo $row['page_title']; ?>%0A https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?> %0A %23SantaRadio %23Christmas <?php echo $row['twitter']; ?>" title="<?php echo $row['page_title']; ?>"  >
<i class="fa fa-twitter fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i>
</a>



<a href="#" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(location.href),'facebook-share-dialog','width=626,height=436');return false;"><i class="fa fa-facebook fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>
 


<a href="https://plus.google.com/share?url=https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?>" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus fa-2x" title="" style="margin-right:6px;margin-left:10px"> </i></a>


<a  href="javascript:void(0)" onclick="window.open( 'http://www.linkedin.com/shareArticle?mini=true&url=https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?>', 'sharer', 'toolbar=0, status=0, width=626, height=436');return false;" title="Linkedin"><i class="fa fa-linkedin fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>




</p>
</div> </div>
                        
                        
                        
                       
                       
                       
                       
                       
                       
                       
                       
                        
                        
                    </div>
                </div>
            </div>
	</div>
    
    
    
    
    
    
    
    

       
   

   <?php include 'assets/php/footer.php';?>
   
   
   

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
    
        <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    


    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>

</body>

</html>

