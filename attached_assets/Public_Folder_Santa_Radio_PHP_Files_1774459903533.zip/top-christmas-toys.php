
<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>




<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="<?php echo $row['video']; ?>">


        <title>Top Christmas Toys 2017</title>

    <meta name="description" content="2017 sees some amazing toys and here we have compiled the current Top toys as requested this Christmas.">
     <meta name="twitter:card" content="app">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:description" content="2017 sees some amazing toys and here we have compiled the current Top toys as requested this Christmas.">
<meta name="twitter:app:id:iphone" content="1021183593">
<meta name="twitter:app:id:ipad" content="1021183593">
<meta name="twitter:app:id:googleplay" content="com.slinkyapps.santaradio">
<meta name="twitter:app:country" content="GB">
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


   

    
    




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
   
   <style>
   
   
   
	
	@media only screen and (max-width: 1026px) {
    .hide22{
	display:none;
}
	
	
	}
	
	
	</style>
    


</head>



<body id="page-top" >

 <!-- onload="timer = setTimeout('reload()',1);" --> 

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                    <?php include 'assets/php/menu.php';?>  
                    
             
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
   
   
   
   
   
   
    <section class="cta4">
        <div class="cta-content">
            <div class="container" style="text-align:center; color:#FFFFFF;">
             <img  src="assets/img/santa-radio-logo.png" alt="Santa Messages - <?php // echo Config::get('seo29.m1'); ?>" title="Santa Messages - <?php // echo Config::get('seo29.m2'); ?>"   class="img-responsive center-block " width="384">
             


<h1><?php  // echo $row['page_title']; ?> </h1>
				<p class="text-muted"><?php // echo $row['info']; ?></p>


                 
             
             <p>
             
 </p>
             
       
          </div>
        </div>
      
    </section>
    
    
    

    
        
    
    
    
        
   
    
    
    
    
    
    
    
    
    
    
    

    
   

         
<div class="container">



<div class="row">
<div class="col-md-12" >
<h2>It’s the most wonderful time of the year….and the most expensive.</h2>
<p>With Christmas only around the corner, (<?php
$christmas = strtotime('25 December 2017');
$now = time();
$timeleft = $christmas-$now;
$daysleft = round((($timeleft/24)/60)/60); //probably...
echo "$daysleft";
?>
 days to be precise) we have compiled a ‘most wanted’ toys list. Not only have we done that, but we have scoured the internet to find the best prices. 
As much as we all love Christmas, it’s much more than how much money you spend and we mustn’t lose sight of the actual meaning – more presence than presents so, with that in mind, don’t get sucked into buying willy nilly.
</p>
</div>
</div>









<div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #1: Luvabella Doll (age 3+) £99.99 Available <a href="https://goo.gl/j8pXpK" target="_blank">here</a> at Smyths Toys</h2> 
<p>The early Christmas toy buzz has tipped this Luvabella doll to be the new ‘Hatchimal of 2017’. The rush for the Hatchimal last year was somewhat stressful, if not amusing, and we are sure there will be many parents around the country keen to avoid getting caught up in a repeat of last year’s ‘hatching madness’. What’s all the fuss about? Well, this lifelike Luvabella Doll responds affectionately to love, changing her expression just like a real baby and the unique selling point on this doll is the way she interactively responds. Tickle her tummy and she giggles, give her a bottle and she will “drink”.</p>
</div>
</div>
<div class="col-md-6" >
<br>
<img  alt="Luvabella Doll (age 3+) £99.99 Available at Smyths Toys" title="Luvabella Doll (age 3+) £99.99 Available at Smyths Toys" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/luvabella.jpg" />
</div>
</div>
<br>
 
 
 
 
<div class="row">
<div class="col-md-6" >
<br>
<img  alt="Star Wars Bladebuilders Path of the Force Lightsaber (age 4+) £49.99 available at The Entertainer" title="Star Wars Bladebuilders Path of the Force Lightsaber (age 4+) £49.99 available at The Entertainer" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/star-wars-bladebuilders-path-of-the-force-lightsaber.png" />
</div>
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #2: Star Wars Bladebuilders Path of the Force Lightsaber (age 4+) £49.99 available <a href="https://goo.gl/BhsYV6" target="_blank">here</a> at The Entertainer</h2> 
<p>The early Christmas toy buzz has tipped this Luvabella doll to be the new ‘Hatchimal of 2017’. The rush for the Hatchimal last year was somewhat stressful, if not amusing, and we are sure there will be many parents around the country keen to avoid getting caught up in a repeat of last year’s ‘hatching madness’. What’s all the fuss about? Well, this lifelike Luvabella Doll responds affectionately to love, changing her expression just like a real baby and the unique selling point on this doll is the way she interactively responds. Tickle her tummy and she giggles, give her a bottle and she will “drink”.</p>
</div>
</div>
</div>
<br>
	 




<div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #3: Beauty and the Beast Tea Set (age 3+) £15.74 (save 25%) with free delivery available <a href="https://goo.gl/VKcJgh" target="_blank">here</a> at The Disney Store</h2> 
<p>It's always time for tea with this fabulous Beauty And The Beast tea set! With a glitter-trimmed tray, a talking Mrs Potts and four cups including Chip, it's certain to create hours of fun.  </p>
</div>
</div>
<div class="col-md-6" >
<br>
<img  alt="Beauty and the Beast Tea Set (age 3+) £15.74 (save 25%) with free delivery available at The Disney Store" title="Beauty and the Beast Tea Set (age 3+) £15.74 (save 25%) with free delivery available at The Disney Store" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/beauty-and-the-beast.jpg" />
</div>
</div>
<br>
 
 
 
 
<div class="row">
<div class="col-md-6" >
<br>
<img  alt="Fisher Price Teach ‘N’ Tag Movi (age 3-6 years) £34.99 available at Smyths Toys" title="Fisher Price Teach ‘N’ Tag Movi (age 3-6 years) £34.99 available at Smyths Toys" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/teach-and-tag.jpg" />
</div>
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #4: Fisher Price Teach ‘N’ Tag Movi (age 3-6 years) £34.99 available <a href="https://goo.gl/VKcJgh" target="_blank">here</a> at Smyths Toys</h2> 
<p>This amazing little robot is in the same pre-school learning category as Fisher-Price’s ‘Code-A-Pillar’, which was a big hit last year and sold out pretty fast. With three modes of play, Movi asks questions, prompts direction and encourages children to move along with him - helping to engage their critical thinking skills. </p>
</div>
</div>
</div>
<br>
 
 
	 
	 
	 
	 
	 
	 
	 
<div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #5: Anki Overdrive Fast & Furious Edition (age 8+) £169.99 available <a href="https://goo.gl/FyW68N" target="_blank">here</a> at Toys R Us </h2> 
<p>The newest edition of the hit robotic battle-racing experience, this app-controlled flexible racing track incorporates all the fun of the original Anki kit but with a Fast & Furious theme. This piece of kit is for children…..obviously!</p>
</div>
</div>
<div class="col-md-6" >
<br>
<img  alt="Anki Overdrive Fast & Furious Edition (age 8+) £169.99 available at Toys R Us" title="Anki Overdrive Fast & Furious Edition (age 8+) £169.99 available at Toys R Us" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/anki-overdrive.jpg" />
</div>
</div>
<br>
 
 
 
 
<div class="row">
<div class="col-md-6" >
<br>
<img  alt="Djeco Topanifarm Cubes Infants (18 months+) £16 available at Selfridges" title="Djeco Topanifarm Cubes Infants (18 months+) £16 available at Selfridges" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/topanifarm.jpg" />
</div>
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #6: Djeco Topanifarm Cubes Infants (18 months+) £16 available <a href="https://goo.gl/hwjWdC" target="_blank">here</a> at Selfridges</h2> 
<p>A fun and exciting update on the usual traditional stacking cubes, this Animal-themed set is a great way to encourage your little one to improve their hand-eye co-ordination. They’ll have hours of fun trying to match the correct animal to its home then stacking up the cubes without knocking them down.  </p>
</div>
</div>
</div>
<br>
	 
	 
	 
	 
	 
	 
	 <div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #7: Paw Patrol Sea Patroller Vehicle (age 3+): £62.99 with free delivery available <a href="https://goo.gl/EC8TSs" target="_blank">here</a> at John Lewis</h2> 
<p>The Air Patroller was one of last years big sellers and with Paw Patrol continuing to increase in popularity, we are sure this will be a sell out before Christmas. Equipped with flashing lights, sounds and a detachable anchor, this rescue vehicle comes with everything that's needed to navigate the waters around Adventure Bay.</p>
</div>
</div>
<div class="col-md-6" >
<br>
<img  alt="Paw Patrol Sea Patroller Vehicle (age 3+): £62.99 with free delivery available at John Lewis" title="Paw Patrol Sea Patroller Vehicle (age 3+): £62.99 with free delivery available at John Lewis" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/paw-patrol.jpg" />
</div>
</div>
<br>
 
 
 
 
<div class="row">
<div class="col-md-6" >
<br>
<img  alt="GLTC Walnut Toy Farm (age 3+): £72.00 – 20% off £50 using code CHERRY20 (ends Monday 30th October) available at GLTC" title="GLTC Walnut Toy Farm (age 3+): £72.00 – 20% off £50 using code CHERRY20 (ends Monday 30th October) available at GLTC" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/walnut-toy-farm.jpg" />
</div>
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #8: GLTC Walnut Toy Farm (age 3+): £72.00 – 20% off £50 using code CHERRY20 (ends Monday 30th October) available <a href="https://goo.gl/LpiRhH" target="_blank">here</a> at GLTC </h2> 
<p>This gorgeous toy farm has everything children need to inspire all manner of rural adventures; it's also one of the best wooden toys for unisex play.</p>
</div>
</div>
</div>
<br>
	 
	 
	 
	 <div class="row">
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #9: Transformers: The Last Knight RC Sqweeks (age 6+):  £35.00 – 35% price drop – free click and collect - available <a href="https://goo.gl/JrNv8L" target="_blank">here</a> at John Lewis</h2> 
<p>Autobot Sqweeks is the smallest of his fellow bots, but his spark shines just as bright. Despite being in disrepair, Autobot Sqweeks perseveres, always motivated to help all living beings.
Imagine jumping into Transformers: The Last Knight action with this Autobot Sqweeks Remote Control Action Figure. In Transformers: The Last Knight, humanity is at war with the Transformers. Optimus Prime is gone and the key to saving the future lies buried in the secrets of the past and the hidden history of Transformers on Earth.
</p>
</div>
</div>
<div class="col-md-6" >
<br>
<img  alt="Transformers: The Last Knight RC Sqweeks (age 6+):  £35.00 – 35% price drop – free click and collect - available at John Lewis" title="Transformers: The Last Knight RC Sqweeks (age 6+):  £35.00 – 35% price drop – free click and collect - available at John Lewis" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/transformers-the-last-knight.jpg" />
</div>
</div>
<br>
 
 
 
 
<div class="row">
<div class="col-md-6" >
<br>
<img  alt="FurReal Roarin’ Tyler The Playful Tiger (age 4+)  £99.99 (save £34.00) available at Argos" title="FurReal Roarin’ Tyler The Playful Tiger (age 4+)  £99.99 (save £34.00) available here Argos" class="img-responsive  imageborder"   src="https://www.santaradio.co.uk/blog-images/fur-real-tiger.jpg" />
</div>
<div class="col-md-6" >
<br>
<div class="effect1">
<h2>Top toy #10: FurReal Roarin’ Tyler The Playful Tiger (age 4+)  £99.99 (save £34.00) available <a href="https://goo.gl/b2eQQX" target="_blank">here</a> at Argos</h2> 
<p>The Roarin' Tyler, the Playful Tiger pet is ready to play. And his favourite way to play is to ROAR! Make noise and he roars back. Talk to him and he responds! This tiger cub responds to sounds and touch with 100+ sound-and-motion combinations! Pet his head and his eyes might close. Pet him on his muzzle and he moves!</p>
</div>
</div>
</div>
<br>
	 
	 
	 
	 
	 
	 

 
 
 
 
 
 
 
 

<div class="row">
<div class="col-md-12" >

<p>
If you find any of the toys listed above are sold out, here’s a great website to track stock and stay ahead of the game! <a href="https://www.stockinformer.co.uk" target="_blank">www.stockinformer.co.uk</a>
 
</p>


<hr>
 
 <br>
 


<div style="text-align:center">
<p>



 <a  href="https://twitter.com/intent/tweet?text=<?php echo $row['page_title']; ?>%0A https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?> %0A %23SantaRadio %23Christmas <?php echo $row['twitter']; ?>" title="<?php echo $row['page_title']; ?>"  >
<i class="fa fa-twitter fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i>
</a>



<a href="#" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(location.href),'facebook-share-dialog','width=626,height=436');return false;"><i class="fa fa-facebook fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>
 


<a href="https://plus.google.com/share?url=https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?>" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus fa-2x" title="" style="margin-right:6px;margin-left:10px"> </i></a>


<a  href="javascript:void(0)" onclick="window.open( 'http://www.linkedin.com/shareArticle?mini=true&url=https://www.santaradio.co.uk/blog?u=<?php echo $row['url']; ?>', 'sharer', 'toolbar=0, status=0, width=626, height=436');return false;" title="Linkedin"><i class="fa fa-linkedin fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>




</p>
</div> </div>
                        
                        
                        
                       
                       
                       
                       
                       
                       
                       
                       
                        
                        
                    </div>
                </div>
            </div>
	</div>
    
    
    
    
    
    
    
    

       
   

   <?php include 'assets/php/footer.php';?>
   
   
   

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
    
        <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    


    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>

</body>

</html>

