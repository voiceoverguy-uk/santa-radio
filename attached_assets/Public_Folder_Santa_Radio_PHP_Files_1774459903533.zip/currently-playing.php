  
<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>


  <?php
$page = $_SERVER['PHP_SELF'];
$sec = "20";
?>
  
  
   <? 
	$thesong = file_get_contents( "radiodocs/Nowplaying.txt" ); 
 	
    $str2 = trim($thesong);

   $parts = explode(" - ", $str2);
   $one = $parts[0];
   $two = $parts[1];
   $two = addslashes($two);
   
$objConnect = mysql_connect("localhost","cl57-thesongs","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl57-thesongs");

$strSQL = "SELECT * FROM messages2  WHERE artist = '$one' && song = '$two'";

$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");




if (mysql_num_rows($objQuery) == 0) { ?>
	
	
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="canonical" href="https://www.santaradio.co.uk/currently-playing" />
	
     <title><?php echo Config::get('seoplaying.s1'); ?></title>
        
        <meta name="description" content="<?php echo Config::get('seoplaying.s2'); ?>">
    
     <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
  
     <meta http-equiv="refresh" content="<?php echo $sec?>;URL='https://www.santaradio.co.uk/currently-playing'">

    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link href="assets/css/new-age.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    

   
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}
</script>



    

</head>

<body id="page-top" style="background-color:#222222">

	<?php include 'assets/php/fullnav.php';?>  
    
    
   

    
    
    
     <section class="cta4">
        <div class="cta-content">
            <div class="container">
            
               <div class="container">
        
        
         <div class="row"  >
         <div class="col-sm-12">
         
         <div  style=" padding-top:40px">
         
         
   
                  <img src="assets/img/santa-radio-logo.png" alt="<?php echo Config::get('seoplaying.s1'); ?>" title="<?php echo Config::get('seoplaying.s1'); ?>"  class="img-responsive center-block" width="564">
               
                
         <br>    <br>    
   
     

       
   
  
        
     </div></div></div>
         
        
         <div class="container">
        
        
         <div class="row" style="max-width:500px;  margin: auto;">
         <div class="col-sm-12" style="color:#DBDBDB; text-align:center; margin-top:-60px" >
       
         

          <?php echo html_entity_decode(Config::get('seoplaying.s3')); ?>



   <img  src="assets/img/FaceBoth.png"  class="img-responsive center-block " alt="<?php echo Config::get('seoplaying.s1'); ?>" title="<?php echo Config::get('seoplaying.s1'); ?>" width="284">
<h1></h1>












    
    
   
       
   
   
   
   
   
   
   
   <?
   
   
   
   
} else { 
 

while($objResult = mysql_fetch_array($objQuery))
{
?>

 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="canonical" href="https://www.santaradio.co.uk/currently-playing" />


  
      <title>Currently playing: <?=$objResult["artist"]?> - <?=$objResult["song"]?></title>

    <meta name="description" content="<?=$objResult["info"]?> on Santa Radio">
    
    
    <meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@WeAreSantaRadio">
<meta name="twitter:title" content="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Santa Radio">
<meta name="twitter:description" content="<?=$objResult["info"]?>">
<meta name="twitter:image" content="../assets/img/artists/<?=$objResult["image"]?>">

    
    
     <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">

    
    
 <link rel="apple-touch-icon" sizes="57x57" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="192x192"  href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/artists/<?=$objResult["image"]?>">
<link rel="manifest" href="assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/img/artists/<?=$objResult["image"]?>">
<meta name="theme-color" content="#ffffff">


    
    <script type="text/javascript">
function toggleDiv(divId) {
   $("#"+divId).slideToggle();
}
</script>
    

    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link href="assets/css/new-age.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    

   
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}
</script>



    

</head>

<body id="page-top" style="background-color:#222222">

<?php include 'assets/php/fullnav.php';?>  
    
    
    
   

    
    
    
     <section class="cta4">
        <div class="cta-content">
            <div class="container">
            
               <div class="container">
        
        
         <div class="row"  >
         <div class="col-sm-12">
         
         <div  style=" padding-top:40px">
         
         
   
                  <img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio"  class="img-responsive center-block" width="564">
               
                
         <br>    <br>    
   
     

       
   
  
        
     </div></div></div>
         
        
         <div class="container">
        
        
         <div class="row" style="max-width:500px;  margin: auto;">
         <div class="col-sm-12" style="color:#DBDBDB; text-align:center; margin-top:-60px" >
       
         



<h2><?=$objResult["artist"]?></h2>
<h1><?=$objResult["song"]?></h1>








 <button style="background-color:#E8E8E8"  onClick="javascript:toggleDiv('myContent');" type="submit" id="submit" class="btn btn-xl page-scroll center-block">Lyrics</button>
  <br>

<div id="myContent" style="max-width:450px; background-color: #FFFFFF; border-radius: 25px;margin-left: auto;margin-right: auto; margin-bottom:20px;padding:20px;display:none;}">
   

   
   
   <?  
   

   if (!isset($objResult["lyrics"]) || $objResult["lyrics"] !== '') {
  


 
}

else{
	
	?>
   
   <br>
    <p style="color:#2D2D2D">The Elves are working on it, come back soon.</p>
   
	
	<?
}
?>





 
  <? $duncan = nl2br($objResult["lyrics"]); ?>
    <p style="color:#2D2D2D"><?php echo $duncan ?></p>
  
  



</div>










<img class="img-rounded img-responsive center-block" src="../assets/img/artists/<?=$objResult["image"]?>" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<br>

<?  
   
   $thelink = $objResult["info"];
   
   
   if (!isset($thelink) || $thelink !== '') {
  

  
  
  ?>
   <p><?=$objResult["info"]?></p>
  
  <?
}

?>






<br>






<br>






 <a  href="https://twitter.com/intent/tweet?text=My favourite %23Christmas song on Santa Radio - <?=$objResult["artist"]?> - <?=$objResult["song"]?> %0A @WeAreSantaRadio %0A %23christmasmusic"  ><i style="color:#F4F4F4" class="fa fa-twitter fa-2x" aria-hidden="true"></i></a>

     <br><br>
     
     
     
   <?  
   
   $thelink = $objResult["link"];
   
   
   if (!isset($thelink) || $thelink !== '') {
  

  
  
  ?>
    <a style=" background-color:#E8E8E8" target="_blank" class="btn btn-outline btn-xl center-block" href="<?=$objResult["link"]?>" title="More info on <?=$objResult["artist"]?> - <?=$objResult["song"]?>">More info about<br><strong><?=$objResult["artist"]?></strong></a>


  <?
}

?>








 <?  
   

   if (!isset($objResult["youtube"]) || $objResult["youtube"] !== '') {
  

?>



<br>
<h2>Music Video</h2>



 <?php
  $browser = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    if ($browser == true){
		
		
		?>
        
        <a  href="https://www.youtube.com/watch?v=<?=$objResult["youtube"]?>">
<img class="img-rounded img-responsive center-block" src="https://img.youtube.com/vi/<?=$objResult["youtube"]?>/hqdefault.jpg" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<img style="margin-top:-76%;" class="img-rounded img-responsive center-block" src="assets/img/video-border.png" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >
 </a>
        
        <?

  }
  else{  ?>
	  
	<a class="video"  title="<?=$objResult["artist"]?> - <?=$objResult["song"]?>" href="https://www.youtube.com/watch?v=<?=$objResult["youtube"]?>">
<img class="img-rounded img-responsive center-block" src="https://img.youtube.com/vi/<?=$objResult["youtube"]?>/hqdefault.jpg" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >

<img style="margin-top:-76%;" class="img-rounded img-responsive center-block" src="assets/img/video-border.png" alt="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio" title="<?=$objResult["artist"]?> - <?=$objResult["song"]?> - Christmas Radio"  >
 </a>
<?	  
  }
?>




  


<?
 
}

else{
	

  
  
}
?>





 
 
 
 
 
 
 
 



 
  
<?
}
?>
 
  
<?
}
?>








            </div>
               
    
                                
               </div>
               
                        
       
    

                
               </div>
                
                 
            </div>
            
                
                
                  
              

 
        </div>
        
                
       
           
        </div>
        </div>
      
    </section>
    
    
    
    
   
       

 
   

   <?php include 'assets/php/footer.php';?>

    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/new-age.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
      <script type="text/javascript" src="assets/js/custom.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
	<script type="text/javascript" src="fancybox-youtube/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" type="text/css" href="fancybox-youtube/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
    <script type="text/javascript" src="fancybox-youtube/fancybox/video.js"></script>
 	


     <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>


	

   

</body>

</html>

       

 
   

  

    

