<html xmlns="https://www.w3.org/1999/xhtml">
<head>
    <title>Twitter Profile Demo using jQuery</title>
    <script src="https://code.jquery.com/jquery-1.7.1.min.js" 
            type="text/javascript"></script>
</head>
<body>
  <?php 
    // integer starts at 0 before counting
    $i = 0; 
    $dir = 'theadmin/';
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false){
            if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
                $i++;
        }
    }
    // prints out how many were in the directory
    echo "There were $i files";
?>

</body>

</html>

