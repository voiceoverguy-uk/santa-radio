

<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">


        <title><?php echo Config::get('seoblog.sx1'); ?></title>
<meta name="description" content="<?php echo Config::get('seoblog.sx3'); ?>">

	   
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:title" content="<?php echo Config::get('seoblog.sx1'); ?>">
<meta name="twitter:description" content="<?php echo Config::get('seoblog.sx3'); ?>" >
<meta name="twitter:image" content="https://www.santaradio.co.uk/assets/favicons/android-icon-192x192.png" />


    
   
   <script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "item": {
      "@id": "https://www.santaradio.co.uk",
      "name": "Santa Radio",
      "image": "https://www.santaradio.co.uk/assets/favicons/android-icon-192x192.png"
    }
  },{
    "@type": "ListItem",
    "position": 2,
    "item": {
      "@id": "https://www.santaradio.co.uk/christmas-news",
      "name": "Christmas News",
      "image": "https://www.santaradio.co.uk/assets/favicons/android-icon-192x192.png"
    }
  }]
}
</script>
   
   
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


   

    
    




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
   
   <style>
   
   
   
	
	@media only screen and (max-width: 1026px) {
    .hide22{
	display:none;
}
	
	
	}
	
	
	</style>
    


</head>



<body id="page-top" >

 <!-- onload="timer = setTimeout('reload()',1);" --> 

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top"  style="background-color: white">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                  <?php include 'newmenu.php';?>  
                    
             
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
   
   
   
   
   
   
    <section class="cta4">
        <div class="cta-content">
            <div class="container" style="text-align:center; color:#FFFFFF;">
            
            <br><br>
             <img  src="assets/img/santa-radio-logo.png" alt="Santa Messages - <?php echo Config::get('seo29.m1'); ?>" title="Santa Messages - <?php echo Config::get('seo29.m2'); ?>"   class="img-responsive center-block " width="384">
             
           <h1><?php echo Config::get('seoblog.sx3'); ?></h1>
                 <p class="text-muted"><?php echo Config::get('seoblog.sx4'); ?></p>
             
             <p>
             
 </p>
             
       
          </div>
        </div>
      
    </section>
    
    
    

    
        
    
    
    
        
   
    
    
    
    
    
    
    
    
    
    
    

    
   
 <section id="features" class="features" style="margin-top:-50px;">
        <div class="container">
         
    
      
      
      
      
      
      
                    <div class="col-md-4" style="min-height: 330px;">
 <a href="https://santaradio.co.uk/blog/the-10-greatest-christmas-songs-of-all-time" style="text-decoration: none; color:#151515">
<h3>Greatest Christmas Songs</h3>
<img src="https://www.santaradio.co.uk/blog-images/the-10-greatest-christmas-songs-of-all-time.jpg"  class="img-responsive" alt="Greatest Christmas Songs" title="Greatest Christmas Songs">
<span >
<p>The top 10 Greatest Christmas Songs of all Time 
</p>
</span>

</a></div>
     
     
      
                 <div class="col-md-4" style="min-height: 330px;">
 <a href="https://santaradio.co.uk/blog/the-five-best-ways-to-get-in-the-mood-for-christmas" style="text-decoration: none; color:#151515">
<h3>Get in the mood</h3>
<img src="https://www.santaradio.co.uk/blog-images/ways-to-get-in-the-mood-for-christmas1.jpg"  class="img-responsive" alt="The Five Best Ways to Get in the Mood for Christmas!" title="The Five Best Ways to Get in the Mood for Christmas!">
<span >
<p>The Five Best Ways to Get in the Mood for Christmas!
</p>
</span>

</a></div>
      
      
       
       
        
                 <div class="col-md-4" style="min-height: 330px;">
 <a href="https://santaradio.co.uk/blog/why-do-we-love-christmas-music" style="text-decoration: none; color:#151515">
<h3>Why We Love Xmas Songs?</h3>
<img src="https://www.santaradio.co.uk/blog-images/why-do-we-love-christmas-music1.jpg"  class="img-responsive" alt="Why Do We Love Christmas Songs?" title="Why Do We Love Christmas Songs?">
<span >
<p>For some of us, Christmas just wouldn’t work without Christmas music!
</p>
</span>

</a></div>
          
        
         
             <div class="col-md-4" style="min-height: 330px;">
 <a href="https://santaradio.co.uk/blog/greatest-christmas-films-of-all-time" style="text-decoration: none; color:#151515">
<h3>Greatest Christmas Films</h3>
<img src="https://www.santaradio.co.uk/blog-images/miracle-on-34th-street.jpg"  class="img-responsive" alt="Greatest Christmas Films" title="Greatest Christmas Films">
<span >
<p>Christmas simply wouldn’t be the same without Christmas films. 
</p>
</span>

</a></div>
        
              
         
         
 <div class="col-md-4" style="min-height: 330px;">
 <a href="https://santaradio.co.uk/blog/christmas-gift-ideas" style="text-decoration: none; color:#151515">
<h3>Christmas Gift Ideas</h3>
<img src="https://www.santaradio.co.uk/blog-images/christmas-gift3.jpg"  class="img-responsive" alt="Christmas Gift Ideas" title="Christmas Gift Ideas">
<span >
<p>It’s the most exciting time of the year are you ready to hit the shops?
</p>
</span>




</a>

		  </div>
        
        
        
        
         
         
         
         
         
           <div class="col-md-4" style="min-height: 330px;">
      
      <a href="https://santaradio.co.uk/blog/top-christmas-songs" style="text-decoration: none; color:#151515">
      
      
      <h3>Top Christmas Songs For 2017</h3>

    
<img src="https://www.santaradio.co.uk/blog-images/last-christmas.jpg"  class="img-responsive" alt="Top Christmas Songs For 2017" title="Top Christmas Songs For 2017">

<span >

<p>
It’s <?php echo date('l jS \of F').""; ?> and that can only mean one thing...
</p>
</span>




</a>

		  </div>
        
        
        
         
         
           <div class="col-md-4" style="min-height: 330px;">
      
      <a href="https://www.santaradio.co.uk/blog/top-christmas-toys" style="text-decoration: none; color:#151515">
      
      
      <h3>Top Christmas Toys 2017</h3>

    
<img src="https://www.santaradio.co.uk/blog-images/walnut-toy-farm.jpg"  class="img-responsive" alt="" title="">

<span >

<p>
It’s the most wonderful time of the year... and the most expensive.
</p>
</span>




</a>

		  </div>
         
         
         
         

         
         
          
          
          <?php 



mysql_connect('localhost','cl57-santablog','earwax69');

mysql_select_db('cl57-santablog');


$sql = "SELECT * FROM messages2 ORDER BY rand()"; 

$rs_result = mysql_query ($sql); //run the query

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


      <div class="col-md-4" style="min-height: 330px;">
      
      <a href="https://www.santaradio.co.uk/blog/<?php echo $row['url']; ?>" style="text-decoration: none; color:#151515">
      
      
      <h3><?php echo $row['page_title']; ?></h3>

    
<img src="https://www.santaradio.co.uk/blog-images/<?php echo $row['image']; ?>"  class="img-responsive" alt="" title="">

<span >

<?php echo $row['info']; ?>

</span>




</a>

		  </div>


<?php 

}; 



?> 


          
          
           
        
  






                            
                            
                            
                            
                        </div>
                        
                        
                        
                       
                       
                       
                       
                       
                       
                       
                       
                        
                        
                    </div>
                </div>
            </div>
    </section>
    
    
    
    
    
    
    
    
    
    

       
   

   <?php include 'assets/php/footer.php';?>
   
   
   

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
    
        <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    


    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>

</body>

</html>
