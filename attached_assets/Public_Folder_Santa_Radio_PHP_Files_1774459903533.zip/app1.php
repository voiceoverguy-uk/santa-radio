

<?php require_once 'theadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">

 
    
      <title>Personalised Santa Messages - Santa Radio</title>


    <meta name="description" content="Your child can hear an amazing personalised Christmas message from Santa for free on the website, or you can download the free app.">
    
   
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:title" content="Personalised Santa Messages - Santa Radio">
<meta name="twitter:description" content="Your child can hear a personalised Christmas message from Santa here onm the website, or download the free app." >
<meta name="twitter:image" content="https://www.santaradio.co.uk/assets/favicons/apple-icon-180x180.png" />


    
   
   <script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "item": {
      "@id": "https://www.santaradio.co.uk",
      "name": "Santa Radio",
      "image": "https://www.santaradio.co.uk/assets/favicons/android-icon-192x192.png"
    }
  },{
    "@type": "ListItem",
    "position": 2,
    "item": {
      "@id": "https://www.santaradio.co.uk/personalised-santa-message/all",
      "name": "Personalised Santa Messages",
      "image": "https://www.santaradio.co.uk/assets/favicons/apple-icon-180x180.png"
    }
  }]
}
</script>
   
   
   
    
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
<link rel="manifest" href="assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


    <link rel="mask-icon" href="/assets/favicons/safari-pinned-tab.svg" color="#5bbad5">
    
    




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    
    
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}

function toggleDiv2(divId) {
	
	setTimeout(
    function() {
      $("#"+divId).slideToggle();
    }, 2000);
	
	
}
</script>

  <style>
  .equal, .equal > div[class*='col-'] {  
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    flex:1 0 auto;
}
</style>




</head>

<body id="page-top">


    
    
    
    

    <header>
 <div class="container">
        
        
         <div class="row"  >
         <div class="col-sm-12">
         
         <div  style=" padding-top:10px">
         
         
                <img  src="https://www.santaradio.co.uk/assets/img/santa-radio-logo.png"  class="img-responsive center-block" width="504">
                
                
                  <img  src="https://www.santaradio.co.uk/assets/img/FaceBoth.png"  class="img-responsive center-block" width="204">
                
         <br>      
  
     
<h1 style="text-align:center;" >  
<?php
 $target = mktime(0, 0, 0, 12, 26, 2018) ;
 $today = time () ;
 $difference =($target-$today) ;
 $days =(int) ($difference/86400) ;
 print "$days";
 ?>
 sleeps til Santa
</p></h1>
			<h1 style="text-align:center;" ><a href="karaoke3.php"><span class="fa fa-star" ></span> Lyrics</a></h1>
			
			
			<h1 style="text-align:center;" ><a href="schedule3.php"><span class="fa fa-list" ></span> Schedule</a></h1>
			
			
			
			<h1 style="text-align:center;" ><a href="https://www.santaradio.co.uk/personalised-santa-message-app/all"><span class="fa fa-commenting-o" ></span> Personalised Santa Messages</a></h1>



     <br><br><br><br><br><br>
    
</div></div></div>

   





  
        
        
        <div class="container">
        
        <div class="row" style="text-align:center">
 
  
      
    
          
   
    
       








  

 


     <br>  <br>  <br>  <br>  <br>  <br>  <br>
 
     </div> 
                        
         
       

 
       
    </header>


  
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/new-age.js"></script>
    <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script-messages.js"></script>
    
    
    
    
    



    
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
      <script type="text/javascript" src="assets/js/custom.js"></script>

    
    
    


     <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>
</body>

</html>
