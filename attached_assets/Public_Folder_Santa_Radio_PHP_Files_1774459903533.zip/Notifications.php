<?php require_once 'theadmin/app/init.php';?>
<?php
date_default_timezone_set('Europe/London');
$MainDate = date("Y-m-d H:i:s");  

$TodayDay = date("l"); 
$TomorrowDay = date("l", strtotime("tomorrow"));
$TheHour = date("H"); 
$timestamp = time() - date('Z');
$time = date('H:i:s', time()); // 10:00:00

$time2 = date('H:i:s', strtotime("+1 hour")); // 10:00:00



$now4=new DateTime( 'now');


$DayIn1 = date("l", strtotime("+1 hour"));
$DayIn2 = date("l", strtotime("+2 hour"));
$DayIn3 = date("l", strtotime("+3 hour"));
$DayIn4 = date("l", strtotime("+4 hour"));
$DayIn5 = date("l", strtotime("+5 hour"));
$DayIn6 = date("l", strtotime("+6 hour"));
$DayIn7 = date("l", strtotime("+7 hour"));
$DayIn8 = date("l", strtotime("+8 hour"));
$DayIn9 = date("l", strtotime("+9 hour"));
$DayIn10 = date("l", strtotime("+10 hour"));
$DayIn11 = date("l", strtotime("+11 hour"));
$DayIn12 = date("l", strtotime("+12 hour"));
$DayIn13 = date("l", strtotime("+13 hour"));
$DayIn14 = date("l", strtotime("+14 hour"));
$DayIn15 = date("l", strtotime("+15 hour"));
$DayIn16 = date("l", strtotime("+16 hour"));
$DayIn17 = date("l", strtotime("+17 hour"));
$DayIn18 = date("l", strtotime("+18 hour"));
$DayIn19 = date("l", strtotime("+19 hour"));
$DayIn20 = date("l", strtotime("+20 hour"));
$DayIn21 = date("l", strtotime("+21 hour"));
$DayIn22 = date("l", strtotime("+22 hour"));
$DayIn23 = date("l", strtotime("+23 hour"));
$DayIn24 = date("l", strtotime("+24 hour"));
$DayIn25 = date("l", strtotime("+25 hour"));
$DayIn26 = date("l", strtotime("+26 hour"));
$DayIn27 = date("l", strtotime("+27 hour"));
$DayIn28 = date("l", strtotime("+28 hour"));
$DayIn29 = date("l", strtotime("+29 hour"));
$DayIn30 = date("l", strtotime("+30 hour"));
$DayIn31 = date("l", strtotime("+31 hour"));
$DayIn32 = date("l", strtotime("+32 hour"));
$DayIn33 = date("l", strtotime("+33 hour"));
$DayIn34 = date("l", strtotime("+34 hour"));
$DayIn35 = date("l", strtotime("+35 hour"));
$DayIn36 = date("l", strtotime("+36 hour"));
$DayIn37 = date("l", strtotime("+37 hour"));
$DayIn38 = date("l", strtotime("+38 hour"));
$DayIn39 = date("l", strtotime("+39 hour"));
$DayIn40 = date("l", strtotime("+40 hour"));
$DayIn41 = date("l", strtotime("+41 hour"));

$TheHourIn1 = date("H", strtotime("+1 hour"));
$TheHourIn2 = date("H", strtotime("+2 hour"));
$TheHourIn3 = date("H", strtotime("+3 hour"));
$TheHourIn4 = date("H", strtotime("+4 hour"));
$TheHourIn5 = date("H", strtotime("+5 hour"));
$TheHourIn6 = date("H", strtotime("+6 hour"));
$TheHourIn7 = date("H", strtotime("+7 hour"));
$TheHourIn8 = date("H", strtotime("+8 hour"));
$TheHourIn9 = date("H", strtotime("+9 hour"));
$TheHourIn10 = date("H", strtotime("+10 hour"));
$TheHourIn11 = date("H", strtotime("+11 hour"));
$TheHourIn12 = date("H", strtotime("+12 hour"));
$TheHourIn13 = date("H", strtotime("+13 hour"));
$TheHourIn14 = date("H", strtotime("+14 hour"));
$TheHourIn15 = date("H", strtotime("+15 hour"));
$TheHourIn16 = date("H", strtotime("+16 hour"));
$TheHourIn17 = date("H", strtotime("+17 hour"));
$TheHourIn18 = date("H", strtotime("+18 hour"));
$TheHourIn19 = date("H", strtotime("+19 hour"));
$TheHourIn20 = date("H", strtotime("+20 hour"));
$TheHourIn21 = date("H", strtotime("+21 hour"));
$TheHourIn22 = date("H", strtotime("+22 hour"));
$TheHourIn23 = date("H", strtotime("+23 hour"));
$TheHourIn24 = date("H", strtotime("+24 hour"));
$TheHourIn25 = date("H", strtotime("+25 hour"));
$TheHourIn26 = date("H", strtotime("+26 hour"));
$TheHourIn27 = date("H", strtotime("+27 hour"));
$TheHourIn28 = date("H", strtotime("+28 hour"));
$TheHourIn29 = date("H", strtotime("+29 hour"));
$TheHourIn30 = date("H", strtotime("+30 hour"));
$TheHourIn31 = date("H", strtotime("+31 hour"));
$TheHourIn32 = date("H", strtotime("+32 hour"));
$TheHourIn33 = date("H", strtotime("+33 hour"));
$TheHourIn34 = date("H", strtotime("+34 hour"));
$TheHourIn35 = date("H", strtotime("+35 hour"));
$TheHourIn36 = date("H", strtotime("+36 hour"));
$TheHourIn37 = date("H", strtotime("+37 hour"));
$TheHourIn38 = date("H", strtotime("+38 hour"));
$TheHourIn39 = date("H", strtotime("+39 hour"));
$TheHourIn40 = date("H", strtotime("+40 hour"));
$TheHourIn41 = date("H", strtotime("+41 hour"));


$stringPlaying = Config::get('seo29.'.$TodayDay.''.$TheHour.'');

$string1 = Config::get('seo29.'.$DayIn1.''.$TheHourIn1.'');
$string2 = Config::get('seo29.'.$DayIn2.''.$TheHourIn2.'');
$string3 = Config::get('seo29.'.$DayIn3.''.$TheHourIn3.'');
$string4 = Config::get('seo29.'.$DayIn4.''.$TheHourIn4.'');
$string5 = Config::get('seo29.'.$DayIn5.''.$TheHourIn5.'');
$string6 = Config::get('seo29.'.$DayIn6.''.$TheHourIn6.'');
$string7 = Config::get('seo29.'.$DayIn7.''.$TheHourIn7.'');
$string8 = Config::get('seo29.'.$DayIn8.''.$TheHourIn8.'');
$string9 = Config::get('seo29.'.$DayIn9.''.$TheHourIn9.'');
$string10 = Config::get('seo29.'.$DayIn10.''.$TheHourIn10.'');
$string11 = Config::get('seo29.'.$DayIn11.''.$TheHourIn11.'');
$string12 = Config::get('seo29.'.$DayIn12.''.$TheHourIn12.'');
$string13 = Config::get('seo29.'.$DayIn13.''.$TheHourIn13.'');
$string14 = Config::get('seo29.'.$DayIn14.''.$TheHourIn14.'');
$string15 = Config::get('seo29.'.$DayIn15.''.$TheHourIn15.'');
$string16 = Config::get('seo29.'.$DayIn16.''.$TheHourIn16.'');
$string17 = Config::get('seo29.'.$DayIn17.''.$TheHourIn17.'');
$string18 = Config::get('seo29.'.$DayIn18.''.$TheHourIn18.'');
$string19 = Config::get('seo29.'.$DayIn19.''.$TheHourIn19.'');
$string20 = Config::get('seo29.'.$DayIn20.''.$TheHourIn20.'');
$string21 = Config::get('seo29.'.$DayIn21.''.$TheHourIn21.'');
$string22 = Config::get('seo29.'.$DayIn22.''.$TheHourIn22.'');
$string23 = Config::get('seo29.'.$DayIn23.''.$TheHourIn23.'');
$string24 = Config::get('seo29.'.$DayIn24.''.$TheHourIn24.'');
$string25 = Config::get('seo29.'.$DayIn25.''.$TheHourIn25.'');
$string26 = Config::get('seo29.'.$DayIn26.''.$TheHourIn26.'');
$string27 = Config::get('seo29.'.$DayIn27.''.$TheHourIn27.'');
$string28 = Config::get('seo29.'.$DayIn28.''.$TheHourIn28.'');
$string29 = Config::get('seo29.'.$DayIn29.''.$TheHourIn29.'');
$string30 = Config::get('seo29.'.$DayIn30.''.$TheHourIn30.'');
$string31 = Config::get('seo29.'.$DayIn31.''.$TheHourIn31.'');
$string32 = Config::get('seo29.'.$DayIn32.''.$TheHourIn32.'');
$string33 = Config::get('seo29.'.$DayIn33.''.$TheHourIn33.'');
$string34 = Config::get('seo29.'.$DayIn34.''.$TheHourIn34.'');
$string35 = Config::get('seo29.'.$DayIn35.''.$TheHourIn35.'');
$string36 = Config::get('seo29.'.$DayIn36.''.$TheHourIn36.'');
$string37 = Config::get('seo29.'.$DayIn37.''.$TheHourIn37.'');
$string38 = Config::get('seo29.'.$DayIn37.''.$TheHourIn38.'');
$string39 = Config::get('seo29.'.$DayIn38.''.$TheHourIn39.'');
$string40 = Config::get('seo29.'.$DayIn40.''.$TheHourIn40.'');
$string41 = Config::get('seo29.'.$DayIn41.''.$TheHourIn41.'');





$string = 'Helpers';








if(strstr($string1 , $string)){ echo $TheHourIn1; } 

elseif(strstr($string2 , $string)){ echo $TheHourIn2; } 
elseif(strstr($string3 , $string)){ echo $TheHourIn3; }
elseif(strstr($string4 , $string)){ echo $TheHourIn4; }
elseif(strstr($string5 , $string)){ echo $TheHourIn5; }
elseif(strstr($string6 , $string)){ echo $TheHourIn6; }
elseif(strstr($string7 , $string)){ echo $TheHourIn7; }
elseif(strstr($string8 , $string)){ echo $TheHourIn8; }
elseif(strstr($string9 , $string)){ echo $TheHourIn9; }
elseif(strstr($string10 , $string)){ echo $TheHourIn10; }
elseif(strstr($string11 , $string)){ echo $TheHourIn11; }
elseif(strstr($string12 , $string)){ echo $TheHourIn12; }
elseif(strstr($string13 , $string)){ echo $TheHourIn13; }
elseif(strstr($string14 , $string)){ echo $TheHourIn14; }
elseif(strstr($string15 , $string)){ echo $TheHourIn15; }
elseif(strstr($string16 , $string)){ echo $TheHourIn16; }
elseif(strstr($string17 , $string)){ echo $TheHourIn17; }
elseif(strstr($string18 , $string)){ echo $TheHourIn18; }
elseif(strstr($string19 , $string)){ echo $TheHourIn19; }
elseif(strstr($string20 , $string)){ echo $TheHourIn20; }
elseif(strstr($string21 , $string)){ echo $TheHourIn21; }
elseif(strstr($string22 , $string)){ echo $TheHourIn22; }
elseif(strstr($string23 , $string)){ echo $TheHourIn23; }
elseif(strstr($string24 , $string)){ echo $TheHourIn24; }
elseif(strstr($string25 , $string)){ echo $TheHourIn25; }
elseif(strstr($string26 , $string)){ echo $TheHourIn26; }
elseif(strstr($string27 , $string)){ echo $TheHourIn27; }
elseif(strstr($string28 , $string)){ echo $TheHourIn28; }
elseif(strstr($string29 , $string)){ echo $TheHourIn29; }
elseif(strstr($string30 , $string)){ echo $TheHourIn30; }
elseif(strstr($string31 , $string)){ echo $TheHourIn31; }
elseif(strstr($string32 , $string)){ echo $TheHourIn32; }
elseif(strstr($string33 , $string)){ echo $TheHourIn33; }
elseif(strstr($string34 , $string)){ echo $TheHourIn34; }
elseif(strstr($string35 , $string)){ echo $TheHourIn35; }
elseif(strstr($string36 , $string)){ echo $TheHourIn36; }
elseif(strstr($string37 , $string)){ echo $TheHourIn37; }
elseif(strstr($string38 , $string)){ echo $TheHourIn38; }
elseif(strstr($string39 , $string)){ echo $TheHourIn39; }
elseif(strstr($string40 , $string)){ echo $TheHourIn40; }
elseif(strstr($string41 , $string)){ echo $TheHourIn41; }






















?>