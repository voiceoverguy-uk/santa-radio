<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>





<?php

	
	
	$directory = "http://www.stagcommunications.com/woodhead/woodthorpe2";
$images = glob($directory . "*.jpg");

foreach($images as $image)
{
  echo $image;
}
?>
	
</body>
</html>