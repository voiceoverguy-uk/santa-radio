<?php

///This is the file used by Santa Voicemail and Santa Messages to upload audio


$msg = " ".var_dump($_FILES)." ";
$new_image_name = $_FILES["userfile"]["name"];
move_uploaded_file($_FILES["userfile"]["tmp_name"], getcwd() . "/audio-messages/" . $new_image_name);











?>




