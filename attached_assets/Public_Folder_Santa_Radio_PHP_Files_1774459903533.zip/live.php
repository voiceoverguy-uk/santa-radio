

<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>




<!DOCTYPE html>
<html lang="en"><head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">


        <title><?php echo Config::get('seo.s7'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo.s8'); ?>">
    
    <meta name="twitter:card" content="app">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:description" content="<?php echo Config::get('seo.s8'); ?>">
<meta name="twitter:app:id:iphone" content="1021183593">
<meta name="twitter:app:id:ipad" content="1021183593">
<meta name="twitter:app:id:googleplay" content="com.slinkyapps.santaradio">
<meta name="twitter:app:country" content="GB">

    <meta name="apple-itunes-app" content="app-id=1021183593, affiliate-data=myAffiliateData, app-argument=myURL">
    



    
 <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


    
    
    




    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    <s
    <script src="assets/js/ion.sound.js"></script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


   
   <style>
   
   
   
	
	@media only screen and (max-width: 1026px) {
    .hide22{
	display:none;
}
	
	
	}
	
	
	</style>
    
 <script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="poll.php"></script>


  <script type="text/javascript">
function toggleDiv(divId) {
	
	$("#tableHolder3").load("karaoke4.php?=random2"+new Date().getTime());
	
      $("#"+divId).slideToggle();
   
	
	
  
}
</script>


   <script>
$(document).ready(function() {
	$("#tableHolder").load("bringsong2.php?=random1"+new Date().getTime());
	$("#tableHolder2").load("bringsong3.php?=random2"+new Date().getTime());
	
    $("#tableHolder3").load("karaoke4.php?=random2"+new Date().getTime());
	


  $.ajaxSetup({ cache: false }); // This part addresses an IE bug.  without it, IE will only load the first number and will never refresh
  setInterval(function() {

                   
    $("#tableHolder").load("bringsong2.php?=random3"+new Date().getTime());
	$("#tableHolder2").load("bringsong3.php?=random4"+new Date().getTime());
	
	var p = ("bringsong2.php?=random3"+new Date().getTime());
	var p2 = ("bringsong2.php?=random4"+new Date().getTime());


console.log(p);
console.log(p2);

	
  }, 5000); // the "3000" 
});
</script>




</head>



<body id="page-top" onLoad="myFunction2();" >

 <!-- onload="timer = setTimeout('reload()',1);" --> 

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"><img src="assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                     
                    
             
                  <li>
                        <a class="page-scroll" href="#listen">Listen</a>
                    </li>
                    <li>
                        <a class="page-scroll" target="_blank" href="free-christmas-apps">Apps</a>
                    </li>
                  
                     <li>
                        <a class="page-scroll" target="_blank" href="messages">Messages</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="record" target="_blank">Record Me</a>
                    </li>
                      <li>
                       <a href="christmas-music" target="_blank">Our Music</a>
                    </li>
                    
                      <li>
                        <a class="page-scroll" href="schedule">Schedule</a>
                    </li>
                  
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="container">
        
        
         <div class="row" style="margin-top:100px;" >
         <div class="col-sm-8">
         
           <img  src="assets/img/santa-radio-logo.png" alt="Santa Messages" title="Santa Messages"   class="img-responsive " width="384">
          <a href="http://www.ukchristmasworld.com" target="_blank" title="UK Christmas World">
          <img  src="assets/img/uk-christmas-world.png" alt="UK Christmas World" title="UK Christmas World"   class="img-responsive" width="384"></a>
           
       
         <?php echo html_entity_decode(Config::get('seo.s1')); ?>
        
 
 
 


 
   <div id="download" >
    <a class="badge-link" target="_blank" href="https://itunes.apple.com/us/app/santa-radio/id1021183593"><img width="80px" src="assets/img/download-from-apple-appstore.png" alt="Download Santa Radio from the apple appstore" title="Download Santa Radio from the apple appstore"></a>
    <a class="badge-link" target="_blank" href="https://play.google.com/store/apps/details?id=com.slinkyapps.santaradio"><img width="80px" src="assets/img/download-from-google-play.png" alt="Download Santa Radio from google play" title="Download Santa Radio from google play"></a>
    <a class="badge-link" target="_blank" href="https://www.amazon.com/App-Style-Ltd-Santa-Radio/dp/B0158MYRBM"><img width="80px"  src="assets/img/download-from-amazon.png" alt="Download Santa Radio from amazon" title="Download Santa Radio from amazon"></a>
</div>
   <br><br>
                  
                   
        </div>
         <div class="col-sm-4 center-block" style="max-width:350px">
       <div class="device-mockup iphone6_plus portrait white">
                <div class="device">
                
                <div class="screen"><img style="margin-top:-5px;" id="myImage" src="assets/img/santa-radio-app1.jpg" class="img-responsive" alt="Santa Radio Screenshot from the iPhone" title="Santa Radio Screenshot from the iPhone"></div>
                                
                         <img  id="arrow"  src="assets/img/arrows.png" style=" position:relative; top:90%; " class="img-responsive center-block" alt="Santa Radio" title="Santa Radio">
                      
             
                
<div id="foo7" class="row1-1" onClick="parent.open('https://www.facebook.com/santaradiouk')"></div>
<div id="foo8" class="row1-2" onClick="parent.open('https://twitter.com/wearesantaradio')"></div>
<div id="foo9" class="row1-3" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santavoicemail')"></div>
<div id="foo10" class="row1-4" onClick="parent.open('https://www.santaradio.co.uk/messages')"></div>
                  
                  
<div  id="foo11" class="row2-1" onClick="parent.open('https://www.instagram.com/santaradiouk/')"></div>
<!--
<div  id="foo12" class="row2-2" onClick="parent.open('https://voiceoverstudiofinder.com')"></div>
<div  id="foo13" class="row2-3" onClick="parent.open('https://www.voiceoverguy.co.uk')"></div>
-->
<div  id="foo14" class="row2-4" onclick="myFunction4();"></div>
                  
<div  id="foo15" class="row3-1" onclick="myFunction5();"></div>
<div  id="foo16" class="row3-2" onclick="myFunction6();"></div>
<div  id="foo17" class="row3-3" onclick="myFunction7();"></div>
<div  id="foo18" class="row3-4" onclick="myFunction8();"></div>
                  
<div id="foo19" class="row4-1" onclick="myFunction9();"></div>
<div id="foo20" class="row4-2" onclick="myFunction10();"></div>
<div  id="foo21" class="row4-3" onclick="myFunction11();"></div>
<div id="foo22" class="row4-4" onclick="myFunction12();"></div>
                  
                  
                  
                  <div class="row6-1" onclick="myFunction2();"></div>
                  <div class="row6-2" onclick="myFunction3();"></div>
                  
                    <div id="foo23" class="row6-3 page-scroll" onclick="location.href='#listen'"></div>
                    
                    
                    
                  
<div  id="voicemailbig" class="voicemailbig" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santavoicemail')"></div>


<div id="santatext" class="santatext" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santatext')"></div>
<div id="santahotline" class="santahotline" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santahotline')"></div>
<div id="justasksanta" class="justasksanta" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#justasksanta')"></div>
<div id="sleepstilsanta" class="sleepstilsanta" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#sleepstilsanta')"></div>
<div id="santadash" class="santadash" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santadash')"></div>
<div id="christmasradio" class="christmasradio" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#christmasradio')"></div>
<div id="ultimatesanta" class="ultimatesanta" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#ultimatesanta')"></div>
<div id="santamessages" class="santamessages" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santamessages')"></div>
<div id="santasoundboard" class="santasoundboard" onClick="parent.open('https://www.santaradio.co.uk/free-christmas-apps/#santasoundboard')"></div>             
                  
                  
                  
                  
                  
               
                  
                  
             
             
                
                
                <div  id="foo"  class="phonebut1" onclick="document.getElementById('myImage').src='assets/img/santa-radio-app1.jpg'" ></div>
                <div  id="foo1" class="phonebut2" onclick="document.getElementById('myImage').src='assets/img/santa-radio-app2.jpg'"></div>
                <div  id="foo2" class="phonebut3" onclick="document.getElementById('myImage').src='assets/img/santa-radio-app3.jpg'"></div>
                <div  id="foo3" class="phonebut4" onclick="document.getElementById('myImage').src='assets/img/santa-radio-app4.jpg'"></div>
                <div  id="foo4" class="phonebut5" onclick="document.getElementById('myImage').src='assets/img/santa-radio-app5.jpg'"></div>
                
                
                
                
                
                <div class="button" onclick="myFunction();"></div>
                
                 
                 
                 
                 
   <script type="text/javascript">
				  
		function myFunction(){
			
			
			 document.getElementById('myImage').src='assets/img/santa-radio-app6.jpg';
			
   toggle_visibility('foo')
   toggle_visibility('foo1')
   toggle_visibility('foo2')
   toggle_visibility('foo3')
   toggle_visibility('foo4')
   toggle_visibility('foo23')
   
    toggle_visibility('arrow')
	toggle_visibility('voicemailbig')
	toggle_visibility('santatext')

	 toggle_visibility('santahotline')
	 toggle_visibility('justasksanta')
	 toggle_visibility('sleepstilsanta')
	 toggle_visibility('santadash')
	 toggle_visibility('christmasradio')
	 toggle_visibility('ultimatesanta')
	 toggle_visibility('santamessages')
	 toggle_visibility('santasoundboard')
	 
   
   
   
   toggle_visibility4('foo7')
	toggle_visibility4('foo8')
	toggle_visibility4('foo9')
	toggle_visibility4('foo10')
	toggle_visibility4('foo11')
	///toggle_visibility4('foo12')
	//toggle_visibility4('foo13')
	toggle_visibility4('foo14')
	toggle_visibility4('foo15')
	toggle_visibility4('foo16')
	toggle_visibility4('foo17')
	toggle_visibility4('foo18')
	toggle_visibility4('foo19')
	toggle_visibility4('foo20')
	toggle_visibility4('foo21')
	toggle_visibility4('foo22')
	
	
 
  
  
   
   
}





    function toggle_visibility(id) {
       var e = document.getElementById(id);
       
          e.style.display = 'none';
      
    }
	
	
	
	function toggle_visibility4(id) {
       var e = document.getElementById(id);
       
            e.style.display = 'block';
    }

</script>



















 <script type="text/javascript">
				  
 function myFunction2(){
	 
	  document.getElementById('myImage').src='assets/img/santa-radio-app1.jpg';
	  
	   document.getElementById('arrow').src='assets/img/arrows.png';
	 
   toggle_visibility2('foo')			  
   toggle_visibility2('foo1')
   toggle_visibility2('foo2')
   toggle_visibility2('foo3')
   toggle_visibility2('foo4')
   toggle_visibility2('foo23')
    toggle_visibility2('arrow')
   
   
	
   
   
	toggle_visibility3('foo7')
	toggle_visibility3('foo8')
	toggle_visibility3('foo9')
	toggle_visibility3('foo10')
	toggle_visibility3('foo11')
//	toggle_visibility3('foo12')
//	toggle_visibility3('foo13')
	toggle_visibility3('foo14')
	toggle_visibility3('foo15')
	toggle_visibility3('foo16')
	toggle_visibility3('foo17')
	toggle_visibility3('foo18')
	toggle_visibility3('foo19')
	toggle_visibility3('foo20')
	toggle_visibility3('foo21')
	toggle_visibility3('foo22')
	 toggle_visibility3('voicemailbig')
	 toggle_visibility3('santatext')
	 toggle_visibility3('santahotline')
	 toggle_visibility3('justasksanta')
	 toggle_visibility3('sleepstilsanta')
	 toggle_visibility3('santadash')
	 toggle_visibility3('christmasradio')
	 toggle_visibility3('ultimatesanta')
	 toggle_visibility3('santamessages')
	 toggle_visibility3('santasoundboard')
	 
	
    
   
}


    function toggle_visibility2(id) {
       var e = document.getElementById(id);
       
           e.style.display = 'block';
    }
	
	function toggle_visibility3(id) {
       var e = document.getElementById(id);
       
            e.style.display = 'none';
    }
	

</script>





















<script type="text/javascript">
				  
 function myFunction3(){
	 
    document.getElementById('myImage').src='assets/img/santa-radio-app9.jpg';
	 toggle_visibility2('arrow')
	 toggle_visibility2('voicemailbig')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibility2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>



<script type="text/javascript">
				  
 function myFunction4(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps8.jpg';
	 toggle_visibilit2('arrow')
	 toggle_visibilit2('santatext')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibilit2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction5(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps7.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('santahotline')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>

<script type="text/javascript">
				  
 function myFunction6(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps12.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('justasksanta')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction7(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps6.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('sleepstilsanta')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction8(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps11.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('santadash')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction9(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps5.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('christmasradio')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction10(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps4.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('ultimatesanta')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction11(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps3.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('santamessages')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>


<script type="text/javascript">
				  
 function myFunction12(){
	 
    document.getElementById('myImage').src='assets/img/apps/christmas-apps2.jpg';
	 toggle_visibili2('arrow')
	 toggle_visibili2('santasoundboard')
	
	 document.getElementById('arrow').src='assets/img/arrows2.png';
    
}

    function toggle_visibili2(id) {
       var e = document.getElementById(id);
       
	   e.style.display = 'block';
    }
	
	

</script>




  
</div>



           </div>
           </div>
         
         
        
        
        
        
         

 

                
               
    </header>



 <section id="features" class="features">
  
  <div class="container">
  <div class="row">
  <div class="col-md-12 text-center" >
   
   <div class="section-heading">
   
    <h2>Santa will be live in:</h2>
    
<p class="text-muted">The app offers so many features, here are just a few.</p>
<div style=" display: block;
    margin-left: auto;
    margin-right: auto;">
<div class="clock" style="margin:2em;"></div>
	<div style=" display: block;
    margin-left: auto;
    margin-right: auto;" class="message"></div>
    </div>

	<script type="text/javascript">
		var clock;
		
		$(document).ready(function() {
			var clock;

			clock = $('.clock').FlipClock({
		        clockFace: 'DailyCounter',
		        autoStart: false,
		        callbacks: {
		        	stop: function() {
		        		$('.message').html('The clock has stopped!')
		        	}
		        }
		    });
				    
		    clock.setTime(000880);
		    clock.setCountdown(true);
		    clock.start();

		});
	</script>

	

	</div>


                        
                        
                    </div>
                </div>
            </div>
    </section>



    <section id="listen" class="download bg-primary text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2" >
                
<h2 style="font-size:42px; "  class="section-heading"><?php echo html_entity_decode(Config::get('seo.s2')); ?></h2>
<br>



<div class="row">
  <div class="col-md-3">
  

<a style="cursor:pointer;"  onClick="play()"><img style="margin-left: auto; margin-top:30px; margin-bottom:30px; margin-right: auto; "  id="myImage2" src="assets/img/Stop.png" alt="Santa Radio" title="Santa Radio"   class="img-responsive " width="120"></a>
  
  <?php
  $browser = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    if ($browser == true){

  } else{  ?>  
<a style="cursor:pointer;"  onclick="document.getElementById('player').volume -= 0.1"><img style="margin-left: auto; margin-top:0px; margin-bottom:30px; margin-right: auto; "  id="myImage2" src="assets/img/volume-down.png" alt="Santa Radio" title="Santa Radio"   width="50"></a>
  <a style="cursor:pointer;"  onclick="document.getElementById('player').volume += 0.1"><img style="margin-left: auto; margin-top:0px; margin-bottom:30px; margin-right: auto; "  id="myImage2" src="assets/img/volume-up.png" alt="Santa Radio" title="Santa Radio"    width="50"></a>
    
<?	  
  }
?>
</div>


<div class="col-md-6" style="margin:0; text-align:center;">
<div id="tableHolder2"></div>
</div>






  <div class="col-md-3" style="margin:0; text-align:center">
  
  
  
  <a  href="https://twitter.com/intent/tweet?text=My favourite %23Christmas song on Santa Radio - <?php echo $thesong2; ?> %0A @WeAreSantaRadio %0A %23christmasmusic" title="<?php echo $thesong2; ?>"  ><i style="color:#4099FF;margin-left: auto; margin-right: auto; margin-top:40px; 
    width: 100px; " class="fa fa-twitter fa-5x" aria-hidden="true"></i></a>
    <br>  <br>
   <a onClick="javascript:toggleDiv('myContent');" title="Christmas Song Lyrics">
 <img style="width:45px; cursor:pointer"  src="assets/img/singer.png" class="center-block" title="Christmas Song Lyrics" alt="Christmas Song Lyrics" >   </a>
  <br>
     <a href="currently-playing" target="_blank" title="Currenty playing on Santa Radio" > <img style="width:40px; cursor:pointer" title="Currenty playing on Santa Radio" alt="Currenty playing on Santa Radio"  src="assets/img/info.png" class="center-block" >   </a>
  
  
  </div>
  
</div>






  

       
        
        <!-- 
<audio onloadstart="this.volume=0.3" controls autoplay><source src="https://santaradio.co.uk/playlist.pls" type="audio/mp3">Your browser does not support the audio element.</audio>
      
	  
      -->
    
    <div style="display:none">
<audio onloadstart="this.volume=0.1"  id="player" onerror="playbackFailed()" controls autoplay><source src="https://stream.radio.co/s64f76aae3/listen" type="audio/mp3">Your browser does not support the audio element.</audio>
</div>


<br>
<!-- 
http://149.255.59.164:8041/;stream.mp3 -->




 <script>
 
 
 function playbackFailed() {
   // video playback failed - show a message saying why
   
     alert('Not hearing Santa Radio? Try opening in Google Chrome or Firefox');
   
}



 function play() {
    var audio = document.getElementById('player');
    if (audio.paused) {
        audio.play();
		  document.getElementById('myImage2').src='assets/img/Stop.png';
    }else{
        audio.pause();
			  document.getElementById('myImage2').src='assets/img/Play.png';
    }
	$('player').on("error", function (e) {
        alert("Error at audio tag level!");
    });
}




</script>





<div id="tableHolder"></div>



<a href="schedule" target="_blank" style="text-decoration:none; color:#FFF;font-size:25px; font-weight:bold;  text-shadow: 1px 1px #000;">
<?php


date_default_timezone_set('Europe/London');
$MainDate = date("Y-m-d H:i:s");  

$TodayDay = date("l"); 
$TheHour = date("H"); 
$timestamp = time() - date('Z');
$time = date('H:i:s', time()); // 10:00:00



echo '<p style="text-decoration:none; color:#FFF;font-size:25px; font-weight:bold;  text-shadow: 1px 1px #000;">';
echo 'Current Show: ' ;
echo Config::get('seo29.'.$TodayDay.''.$TheHour.'');
echo '</p>';



?>

</a>







<div id="myContent" style="display:none;">
   

  <span id="tableHolder3"></span>
  <hr>
  



</div>
        
       
       
       
       




 

       
     

       


<p ><?php echo html_entity_decode(Config::get('seo.s3')); ?></p>
<br>
                                    
       <button onClick="self.open('christmas-music')" class="btn btn-outline btn-xl page-scroll" style="margin-top:-15px;width:230px; background-color:#E8E8E8">See the playlist</button>




                </div>
            </div>
        </div>
    </section>

    <section id="features" class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-heading">
                    
                  <?php echo html_entity_decode(Config::get('seo.s4')); ?>

                      
                        <hr>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="device-container">
                        <div class="device-mockup iphone6_plus portrait white">
                            <div class="device">
                                <div class="screen">
                                   
                                    <img style="margin-top:-5px;" src="assets/img/santa-radio-app7.jpg" class="img-responsive" alt="Santa Radio" title="Santa Radio">  </div>
                                    
                                    
                                         <div style=" position: relative; text-align:right;top:64.5%; padding-right:19%; font-weight:bold; color: #E8E2A2 ; font-size:24px; ">
                                    <?php
 $target = mktime(0, 0, 0, 12, 26, 2016) ;
 $today = time () ;
 $difference =($target-$today) ;
 $days =(int) ($difference/86400) ;
 print "$days";
 ?>
            
             </div> 
                                    
                                   
                                    
                                                     
                            </div>
                       
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="feature-item">
                                    <i class="icon-music-tone text-primary"></i>
                                    
                                    <?php echo html_entity_decode(Config::get('seo.s5')); ?>
                                   
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-item">
                                    <i class="icon-camera text-primary"></i>
                                    <?php echo html_entity_decode(Config::get('seo.s6')); ?>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="feature-item">
                                    <i class="icon-present text-primary"></i>
                                    <?php echo html_entity_decode(Config::get('seo.s9')); ?>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-item">
                                    <i class="icon-pencil text-primary"></i>
                                    <?php echo html_entity_decode(Config::get('seo.s10')); ?>
                                   
                                </div>
                            </div>
                        </div>
                        
                         <div class="row">
                            <div class="col-md-6">
                                <div class="feature-item">
                                    <i class="icon-clock text-primary"></i>
                                    <?php echo html_entity_decode(Config::get('seo.s11')); ?>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-item">
                                   <i class="icon-screen-smartphone text-primary"></i>
                                   <?php echo html_entity_decode(Config::get('seo.s12')); ?>
                                  
                                </div>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
    </section>

    <section id="messages" class="cta">
        <div class="cta-content">
            <div class="container">
            
             <?php echo html_entity_decode(Config::get('seo.s13')); ?>
               
            
            
            <?
	 
$conn = mysql_connect('localhost', 'cl57-messages', 'earwax69');
 $db   = mysql_select_db('cl57-messages');
	
	
$objConnect = mysql_connect("localhost","cl57-messages","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl57-messages");


$order_by = "ORDER BY RAND()"; // Default order



$strSQL = "SELECT * FROM messages2 WHERE live='Yes'  ".$order_by." LIMIT 2";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");

?>

            
            

   
<?
while($objResult = mysql_fetch_array($objQuery))
{
?>

 <div class="col-md-6 center-block" style="height:260px" >

<div class="incoming ">
			<table>
				<tr><td class="cell"></td><td class="cell"><b><?=$objResult["name"]?> asks</b><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="call textcell"><?=$objResult["message"]?></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="cell"><span class="datetext"><?=$objResult["date"]?></span></td><td class="cell"></td></tr>
			</table>
		</div>
        
        
		<div class="outgoing">
			<table>
			
				<tr><td class="cell"></td><td class="cell"><b>Santa says</b></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="call textcell"><?=$objResult["reply"]?></td><td class="cell"></td></tr>
				<tr><td class="cell"></td><td class="cell"></td><td class="cell"></td></tr>
			</table>
            
            
        
		</div>
        
     

  
</div>
  
  
   
     
  
<?
}
?>


       

<div>
<br><br>

                
            </div>
        </div>
        
        <div style="margin:0 auto; text-align:center">
            
                <button onClick="self.open('messages')" class="btn btn-outline btn-xl page-scroll" style="width:230px; background-color:#E8E8E8; margin:20px">View all messages</button> 
                <button onClick="self.open('messages')" class="btn btn-outline btn-xl page-scroll" style="width:230px; background-color:#E8E8E8; margin:20px">Message Santa</button>
                </div>
                
                
                </div>
        <div class="overlay"></div>
    </section>
    
    
    
    
    
    
    
    
    
    
    
    
     <section id="schedule" class="cta2">
        <div class="cta2-content">
            <div class="container">
            
            
            
            
             <div class="row">
                <div class="col-md-4 center-block" style="max-width:370px;text-align:center;color:#FFFFFF;">
                   
                  
                   
                      <?php echo html_entity_decode(Config::get('seo.s14')); ?>
               
        
         
                        <div class="device-mockup iphone6_plus portrait black">
                            <div class="device">
                            
                              <div class="screen"><img style="margin-top:-5px;" src="assets/img/santa-radio-app8.jpg" class="img-responsive" alt="Santa Radio"> </div>
                                <div class="screen">
                      <iframe  style="padding-top:60px;  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;" height="100%" width="100%" src="https://www.santaradio.co.uk/schedule2.php" allowtransparency="true"  frameBorder="0">Error, iFrame failed to load.</iframe>
 </div>
                           
                        </div>
                        
                        </div>
        


   <br>


                    </div>
                
            
            
           
           
           
             
                <div class="col-md-4 center-block" style="max-width:370px;text-align:center;color:#FFFFFF;">
                
                
                
                   <?php echo html_entity_decode(Config::get('seo.s15')); ?>
                    
                    
                        <div class="device-mockup iphone6_plus portrait black">
                            <div class="device">
                                <div class="screen"><img style="margin-top:-5px;" src="assets/img/santa-radio-app3.jpg" class="img-responsive" alt="Santa Radio"> </div>
                               
                            </div>
                        </div>
                        
                       
                        
   <br>
                    </div>
                
     
           
           
             
                <div class="col-md-4 center-block" style="max-width:370px;text-align:center;color:#FFFFFF;">
             <?php echo html_entity_decode(Config::get('seo.s16')); ?>

               
                        <div class="device-mockup iphone6_plus portrait black">
                            <div class="device">
                                <div class="screen"><img style="margin-top:-5px;" src="assets/img/santa-radio-app1.jpg" class="img-responsive" alt="Santa Radio"> </div>
                               
                            </div>
                        </div>
                        
                        <br>
                    
                        

                   
                    </div>
             
            
            
           </div>
           
           
           
              
            
            </div>
        </div>
        <div class="overlay"></div>
    </section>
    
    
    
    
    
    
    
       <section id="soudboard" class="cta3">
        <div class="cta3-content">
            <div class="container">
            
            <?php echo html_entity_decode(Config::get('seo.s17')); ?>
            
              
<div style="text-align:center">

<button id="b01" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Are you asleep</button>
<button id="b02" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Been Naughty</button>
<button id="b03" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Cookies</button>
<button id="b04" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Happy Holidays</button>
<button id="b05" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">It's Christmas</button>
<button id="b06" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Jingle Bells</button>
<button id="b07" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Naughty or Nice</button>
<button id="b08" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Merry Christmas</button>
<button id="b09" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Making a List</button>
<button id="b10" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Tis the Season</button>
<button id="b11" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Very Quiet</button>
<button id="b12" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Would You Like?</button>


<button id="b13" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Yes 1</button>
<button id="b14" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">Yes 2</button>
<button id="b15" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">No 1</button>
<button id="b16" class="btn btn-outline btn-xl page-scroll" style="margin:20px;width:230px; background-color:#E8E8E8"">No 2</button>


</div>
 


<div>
  
                
                </div>
                
                
            </div>
        </div>
        <div class="overlay"></div>
    </section>
    
    
    
    
    
    
    
     <section id="naughtylist" class="cta4">
        <div class="cta-content">
            <div class="container" style="color:#FFFFFF">
            
               <?php echo html_entity_decode(Config::get('seo.s18')); ?>



 <div style="text-align:center;color:#FFFFFF" id='poll'></div>
                
       
           
        </div>
        </div>
      
    </section>
    
    
    
    
    
    
    
    
    
    

    <section  id="contact" class="contact bg-primary">
        <div class="container">
            <h2>We <i class="fa fa-heart"></i> new friends!</h2>
            <ul class="list-inline list-social">
                <li class="social-twitter">
                    <a href="https://twitter.com/wearesantaradio" target="_blank"><i class="fa fa-twitter"></i></a>
                </li>
                <li class="social-facebook">
                    <a href="https://www.facebook.com/santaradiouk" target="_blank"><i class="fa fa-facebook"></i></a>
                </li>
                
                 <li class="social-google-plus">
                    <a href="https://www.youtube.com/channel/UCtvHjue7LusTEpMTpByuC8A" target="_blank"><i class="fa fa-youtube"></i></a>
                </li>
                
            </ul>
            <br>
             <h2>Contact Santa Radio</h2>
             <p>For Press or Corporate, feedback and suggestions, get in touch.</p>

        <div class="row">
        
         <div class="col-md-12">
        
         <div style="max-width:700px;margin-left: auto;
    margin-right: auto;">
            <form role="form" id="contactForm" class="contact-form center-block" data-toggle="validator" class="shake" >
            
               <div id="msgSubmit" class="h1 text-center hidden"></div> 
              <div class="clearfix"></div>   

              <div class="form-group">
                <div class="controls">
                  <input type="text" id="name" class="form-control" placeholder="Your Name" required data-error="Please enter your name">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="email" class="email form-control" id="email" placeholder="Your Email" required data-error="Please enter your email">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="text" id="msg_subject" class="form-control" placeholder="Subject" required data-error="Please enter your message subject">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <textarea id="message" rows="7" placeholder="Your Message to Santa" class="form-control" required data-error="Write your message"></textarea>
                  <div class="help-block with-errors"></div>
                </div>  
              </div>

              <button style="background-color:#E8E8E8" type="submit" id="submit" class="btn btn-xl page-scroll"> Send Message </button>
              
              
              
           
            </form>   
            
            </div>  
        
        
         

        
        
        </div>
        
        
        
        </div>
    </section>
    
    
       
   

   <?php include 'assets/php/footer.php';?>

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
    
        <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script.js"></script>
    
    
    <script>
    $(document).ready(function(){

        ion.sound({
            sounds: [
                {name: "Asleep"},
                {name: "Been Naughty"},
				{name: "Cookies"},
				{name: "Happy Holidays"},
				{name: "It's Christmas"},
				{name: "Jingle Bells"},
				{name: "Naughty or Nice"},
				{name: "Merry Christmas"},
				{name: "Making a List"},
				{name: "Tis the Season"},
				{name: "Very Quiet"},
				{name: "Yes1"},
				{name: "Yes2"},
				{name: "No1"},
				{name: "No2"}
				
            ],
            path: "assets/audio/",
            preload: true,
            volume: 1.0
        });


        $("#b01").on("click", function(){
            ion.sound.play("Asleep");
        });

        $("#b02").on("click", function(){
            ion.sound.play("Been Naughty");
        });
		$("#b03").on("click", function(){
            ion.sound.play("Cookies");
        });
		$("#b04").on("click", function(){
            ion.sound.play("Happy Holidays");
        });
		$("#b05").on("click", function(){
            ion.sound.play("It's Christmas");
        });
		$("#b06").on("click", function(){
            ion.sound.play("Jingle Bells");
        });
		$("#b07").on("click", function(){
            ion.sound.play("Naughty or Nice");
        });
		$("#b08").on("click", function(){
            ion.sound.play("Merry Christmas");
        });
		$("#b09").on("click", function(){
            ion.sound.play("Making a List");
        });
		$("#b10").on("click", function(){
            ion.sound.play("Tis the Season");
        });
		$("#b11").on("click", function(){
            ion.sound.play("Very Quiet");
        });
		$("#b12").on("click", function(){
            ion.sound.play("What Would You Like");
        });
		$("#b13").on("click", function(){
            ion.sound.play("Yes1");
        });
		$("#b14").on("click", function(){
            ion.sound.play("Yes2");
        });
		$("#b15").on("click", function(){
            ion.sound.play("No1");
        });
		$("#b16").on("click", function(){
            ion.sound.play("No2");
        });
		


    });
</script>


    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>
   
<link rel="stylesheet" href="assets/flip/compiled/flipclock.css">
<script src="assets/flip/compiled/flipclock.js"></script>




</body>

</html>
