

<?php require_once 'theadmin/app/init.php';?>

<?php
error_reporting(0); // Turn off all error reporting
?>
<?php header('Access-Control-Allow-Origin: *'); ?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">


<title><?php echo Config::get('submitsong.submit1') ?></title>


	   
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:title" content="<?php echo Config::get('submitsong.submit1') ?>">
<meta name="twitter:description" content="<?php echo Config::get('submitsong.submit2') ?>" >
<meta name="twitter:image" content="https://www.santaradio.co.uk/assets/favicons/android-icon-192x192.png" />

   
   
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="/assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
<link rel="manifest" href="/assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


   

    
    
<link href="xmas.css" rel="stylesheet">



    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">

    <!-- Theme CSS -->
    <link href="assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" media="screen">
    
    <script src="assets/js/ion.sound.js"></script>


   <style>
   
   
   
	
	@media only screen and (max-width: 1026px) {
    .hide22{
	display:none;
}
	
	
	}
	
	
	</style>
    


</head>



<body id="page-top" >

 <?php include 'assets/php/fullnav.php';?>  
    
   
   
   
   
   
   
    <section class="cta4">
        <div class="cta-content">
            <div class="container" style="text-align:center; color:#FFFFFF;">
             <img  src="assets/img/santa-radio-logo.png" alt="Santa Messages - <?php echo Config::get('seo29.m1'); ?>" title="Santa Messages - <?php echo Config::get('seo29.m2'); ?>"   class="img-responsive center-block " width="384">
             
            
    
             <?php echo html_entity_decode(Config::get('submitsong.submit3')); ?>
         
       
          </div>
        </div>
      
    </section>
    
    
    

    
        
    
    
    
        
   
    
    
    
    
    
    
    
    
    
 
         
         
         
         
    
    
    
    
    
    

    <section  id="contact" class="contact bg-primary">
        <div class="container">
           
        <div class="row">
        
         <div class="col-md-12">
			 
			 
           
             <div style="max-width:700px;margin-left: auto;margin-right: auto;">
           
            <?php echo html_entity_decode(Config::get('submitsong.submit4')); ?>
				 
				 
				 <!--
     
           <form role="form" id="contactForm2" class="contact-form center-block" data-toggle="validator" class="shake" >
            
               <div id="msgSubmit" class="h1 text-center hidden"></div> 
              <div class="clearfix"></div>   

              <div class="form-group">
                <div class="controls">
                  <input type="text" id="name" class="form-control" placeholder="Your name" required data-error="Please enter your name">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="email" class="email form-control" id="email" placeholder="Your email" required data-error="Please enter your email">
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="form-group">
                <div class="controls">
                  <input type="text" id="msg_subject" class="form-control" placeholder="Song title" required data-error="Please enter your song title" >
                  <div class="help-block with-errors"></div>
                </div>
              </div>
               <div class="form-group">
                <div class="controls">
                  <input type="text" class="twitter form-control" id="twitter" placeholder="Your twitter" >
               
                </div>
              </div>
              
              <div class="form-group">
                <div class="controls">
                  <input type="text" class="facebook form-control" id="facebook" placeholder="Your facebook page" >
           
                </div>
              </div>
              
              <div class="form-group">
                <div class="controls">
                  <textarea id="message" rows="7" placeholder="Song information and hyperlinks" class="form-control" required data-error="Please tell us about your song"></textarea>
                  <div class="help-block with-errors"></div>
                </div>  
              </div>
              
              

              <button style="background-color:#E8E8E8" type="submit" id="submit" class="btn btn-xl page-scroll"> Send for consideration </button>
              
              
              
           
            </form>   

-->
				 
				 <a href="mailto:santa@santaradio.co.uk?subject=Submit%20a%20song&body=Before submitting your song, please fully read the Submit a song page before sending this email. Thank you." class="xmasbutton">Send Email</A>
            
            </div>  
        
        
         

        
        
        </div>
        
        
        
        </div>
    </section>
    
    
    
    
    
    
    
    

       
   

   <?php include 'assets/php/footer.php';?>
   
   
   

    <!-- jQuery -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="assets/js/new-age.js"></script>
    
    
    <script type="text/javascript" src="assets/js/form-validator.min.js"></script>  
    <script type="text/javascript" src="assets/js/contact-form-script-song.js"></script>
    


    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script>
    
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68374162-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript" src="assets/js/snowstorm.js"></script>

</body>

</html>
