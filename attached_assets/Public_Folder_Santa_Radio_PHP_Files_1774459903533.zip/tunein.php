

<?php require_once 'theadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="author" content="">

 
    
      <title><?php echo Config::get('seo2.s1'); ?></title>


    <meta name="description" content="<?php echo Config::get('seo2.s2'); ?>">
    
    <meta name="twitter:card" content="app">
<meta name="twitter:site" content="@wearesantaradio">
<meta name="twitter:description" content="<?php echo Config::get('seo2.s2'); ?>">
<meta name="twitter:app:id:iphone" content="1021183593">
<meta name="twitter:app:id:ipad" content="1021183593">
<meta name="twitter:app:id:googleplay" content="com.slinkyapps.santaradio">
<meta name="twitter:app:country" content="GB">
    
    
    
    
 <link rel="apple-touch-icon" sizes="57x57" href="assets/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="assets/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="assets/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="assets/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="assets/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="assets/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
<link rel="manifest" href="assets/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


    
    
    




    

    <!-- Bootstrap Core CSS -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/vendor/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="../assets/vendor/device-mockups/device-mockups.min.css">

    <!-- Theme CSS -->
    <link href="../assets/css/new-age.css" rel="stylesheet">
    
    
     <!-- Animate CSS  -->
    <link rel="stylesheet" type="text/css" href="../assets/css/animate.css" media="screen">
    
    <script src="../assets/js/ion.sound.js"></script>

 <link href="../xmas.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    
    
    
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}

function toggleDiv2(divId) {
	
	setTimeout(
    function() {
      $("#"+divId).slideToggle();
    }, 2000);
	
	
}
</script>

  <style>
  .equal, .equal > div[class*='col-'] {  
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    flex:1 0 auto;
}
</style>




</head>

<body id="page-top">

   <nav id="mainNav" class="navbar navbar-default navbar-fixed-top" style="background-color: white">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile displa y -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="https://www.santaradio.co.uk"><img src="../assets/img/santa-radio-logo.png" alt="Santa Radio" title="Santa Radio" height="30px"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
       
    
                   <?php include 'newmenu.php';?>  
                    
             
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
   

    
		



    <section class="cta10" >
        <div class="cta10-content">
            <div class="container" style="text-align:center; color:#FFFFFF">
            <br><br>
             <img  src="../assets/img/santa-radio-logo.png" alt="Santa Messages - <?php echo Config::get('christmasapps.s1'); ?>" title="Santa Messages - <?php echo Config::get('christmasapps.s1'); ?>"   class="img-responsive center-block " width="384">
				
				
             <h2>The World's Best Christmas Music</h2>
           <p class="text-muted">The world's biggest online Christmas Radio now available on TuneIn<br>Brought to you with <a href="https://festivestudio.co.uk/i/santaradio" target="_blank">FestiveStudio.co.uk</a>  - Your magical Christmas awaits.</p>






				
				
                <div class="col-md-12" align="center">
					
					
					


              <iframe src="https://tunein.com/embed/player/s252505/" style="width:100%; height:100px;" scrolling="no" frameborder="no"></iframe>

			
  

					
		  	 <div id="tableHolder" style="margin-bottom: 30px;" ></div>
					

				
				
				
				
				
				

				
				
				
				
			
      
    </section>

		
		
		
		
    
    
    
















	
	
	
	
	
	
	
	
	
    
    
    
    
    
    

    
									
					
   

   <?php include 'assets/php/footer.php';?>
									
									

<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

<script src="assets/js/new-age.js"></script>
    
								  
								 



</body>
</html>
