<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/new-age.css" rel="stylesheet">

<style>
body {
    font-family: 'Courgette', cursive;
    font-size: 19px;
    background:none;
    text-align:center;
}
</style>

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-sm-12" style="overflow-y:scroll; -webkit-overflow-scrolling:touch;">

<?php

// --- Database Connection (MySQLi) ---
$mysqli = new mysqli("localhost", "cl57-thesongs", "earwax69", "cl57-thesongs");

// Check connection
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// --- Sanitize GET input ---
$id = isset($_GET["s"]) ? intval($_GET["s"]) : 0;

// --- Prepare query ---
$stmt = $mysqli->prepare("SELECT lyrics FROM messages2 WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {

    echo "Sorry, no lyrics found";

} else {

    while ($row = $result->fetch_assoc()) {
        $lyrics = nl2br($row["lyrics"]);
        echo '<p style="font-size:28px">The Lyrics</p>';
        echo "<p>$lyrics</p>";
    }
}

$stmt->close();
$mysqli->close();

?>

        </div>
    </div>
</div>

</body>
</html>

    
   
       

 
   

  

    

