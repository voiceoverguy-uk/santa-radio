[playlist]
NumberOfEntries=1
File1=http://149.255.59.164:8041/listen.pls?sid=1
