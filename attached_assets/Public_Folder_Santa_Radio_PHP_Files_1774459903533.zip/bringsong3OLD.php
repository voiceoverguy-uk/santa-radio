<?php 
$theverabke = time();  
$bring = file_get_contents('radiodocs/Nowplaying.txt'); 
$fullsong = $bring;

 $str2 = trim($bring);
    $parts = explode(" - ", $str2);
    $one = $parts[0];
    $two = $parts[1];
	$str =  $one;
    $str = strtolower($str);
    $id = $str;
    $id = str_replace(' ', '-', $id);

     if (empty($id)){ $strippedartist = "santa-radio"; }

else{ $strippedartist = $id; }





if (empty($fullsong)){ $thefullsong = "Santa Radio";}
else{ $thefullsong = $fullsong; }





?>


<script type="text/javascript">
jQuery(function(){

   // Fade In
   $("#myImage").fadeIn();



});
</script>




<img id="myImage2" src="https://www.santaradio.co.uk/assets/img/artists/<? echo $strippedartist;?>.jpg" 
title="Now playing <? echo $thefullsong;?> on Santa Radio" 
alt="Now playing <? echo $thefullsong;?> on Santa Radio" 
width="210px" 
style="height:210px;  "
class="center-block img-circle" /><img id="myImage" src="https://www.santaradio.co.uk/assets/img/artists/<? echo $strippedartist;?>.jpg?nocache=<?php echo time(); ?>" 
									   

title="Now playing <? echo $thefullsong;?> on Santa Radio" 
alt="Now playing <? echo $thefullsong;?> on Santa Radio" 
width="210px" 
style="height:210px; margin-top:-210px; "
class="center-block img-circle">




<img style="margin-top:-258px" src="assets/img/santa-radio-globe.gif" width="328px" class="center-block" >   
<img style="margin-top:-328px" src="assets/img/santa-radio-globe.png" width="328px" class="center-block" 

title="Now playing <? echo $thefullsong;?> on Santa Radio" 
alt="Now playing <? echo $thefullsong;?> on Santa Radio"

>
	
	